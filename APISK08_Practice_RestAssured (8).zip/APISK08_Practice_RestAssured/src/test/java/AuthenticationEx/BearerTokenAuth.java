package AuthenticationEx;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

import Payload.PayloadData;

public class BearerTokenAuth {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://gorest.co.in";
		
		
		
		String token="Bearer a682a89b74963538f47d3ec72b6af8f655ef7c20f8d1a7e3ad8582ffd8dfdf64";
		
		
	String Response=	given().log().all().header("Authorization",token).header("content-type","application/json")
		.body(PayloadData.goRestPayload())
		.when().post("public/v2/users")
		.then().log().all()
		.assertThat().statusCode(201)
		.extract().response().asString();
	
	System.out.println("The response is  "+Response);
		
		
		

	}

}
