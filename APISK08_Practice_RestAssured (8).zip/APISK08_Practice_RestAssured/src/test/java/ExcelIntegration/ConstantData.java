package ExcelIntegration;

public class ConstantData {
	
	public static final String ExcelPath="D:\\TestData25thOct.xlsx";
	public static final String SheetName="Sheet1";
	

}
