package HandlingDBConnection;

public class SQLQueryEx {
	
	public static String sqlQuery()
	{
		String str= "select * from apisk08.employees where address='Delhi'";
		return str;
		
	}
	

}
