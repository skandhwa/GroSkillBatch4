package MISC;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

import Payload.PayloadData;

public class HandlingXMLData {

	public static void main(String[] args) {
	
		RestAssured.baseURI="https://petstore.swagger.io";
		
	String Response=	given().log().all().header("content-type","application/xml")
		.body(PayloadData.getPayloadData(5))
		.when().post("v2/pet")
		.then().log().all()
		.extract().response().asString(.basePath).Response;
	
	System.out.println("Response is  "+Response);
		
		
		
		

	}

}
