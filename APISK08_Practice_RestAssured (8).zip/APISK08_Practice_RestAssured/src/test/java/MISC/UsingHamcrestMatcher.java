package MISC;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class UsingHamcrestMatcher {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://jsonplaceholder.typicode.com/";
		
	String Response=	given().log().all().when().get("posts/1")
		.then().log().all()
		
		.body("userId", equalTo(1))
		.body("title",notNullValue())
		.body("title", startsWith("sun"))
		.body("body", endsWith("cto"))
		.body("userId", greaterThan(0))
		.body("userId", lessThan(10)).
		body("title", containsString("sunt"))
		
		
		
		.extract().response().asString();
		
	
	System.out.println(Response);
		
		
		
		
		
		
		
		
		
		

	}

}
