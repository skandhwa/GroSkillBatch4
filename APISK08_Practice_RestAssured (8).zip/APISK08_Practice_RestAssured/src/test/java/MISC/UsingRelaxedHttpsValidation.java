package MISC;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

public class UsingRelaxedHttpsValidation {

	public static void main(String[] args) {
		
		
		String response = 
	            given()
	                .log().all()
	                .relaxedHTTPSValidation()
	            .when()
	                .get("https://self-signed.badssl.com/")
	            .then()
	                .extract()
	                .response()
	                .asString();

	        System.out.println(response);
		
	}

}
