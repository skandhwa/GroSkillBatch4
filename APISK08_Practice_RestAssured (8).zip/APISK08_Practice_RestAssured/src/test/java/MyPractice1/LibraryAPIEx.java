package MyPractice1;
import static io.restassured.RestAssured.given;

import org.testng.Assert;

import Payload.PayloadData;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class LibraryAPIEx {

	public static void main(String[] args) {
		
		String ExpectedMessage="successfully added";
		
		RestAssured.baseURI="http://216.10.245.166";
		String isbn=Long.toHexString(Double.doubleToLongBits(Math.random())).substring(0, 4);
		Integer aisle= 1000 + new java.util.Random().nextInt(9000);
		
		
		String ExpectedID= isbn+ aisle.toString();
		
		
	String Response=	given().log().all().header("content-type","application/json").
		body(PayloadData.getBookDetails(isbn, aisle)).when().post("Library/Addbook.php")
		.then().log().all().assertThat().statusCode(200)
		.extract().response().asString();
	
	
	JsonPath js=new JsonPath(Response);
	
String Actualmessage=	js.getString("Msg");

Assert.assertEquals(Actualmessage, ExpectedMessage);

String ActualID=js.getString("ID");

Assert.assertEquals(ActualID, ExpectedID);

System.out.println("Test Case Pass");










	
	
	
		
		
		
		
		
		

	}

}
