package POJOEx1;

import static io.restassured.RestAssured.given;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import Payload.PayloadData;
import io.restassured.RestAssured;

public class CreateEmployee {

	public static void main(String[] args) throws JsonProcessingException {
		
		Employee1POJO emp=new Employee1POJO();
		emp.setName("Harry");
		emp.setJob("QA lead");
		emp.setMarried(false);
		emp.setSalary(80000f);
		
		ObjectMapper obj=new ObjectMapper();
		
	String empJSON=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp);
	

	RestAssured.baseURI="https://reqres.in/";
	
	
String Response=	given().log().all()
		
	.header("content-type","application/json")
	.header("x-api-key","reqres-free-v1")
	.body(empJSON)
	
	.when().post("api/users")
	.then().log().all().
	
	assertThat().statusCode(201)
	.extract().response().asString();


System.out.println(Response);

//Employee1POJO empObj=obj.readValue(Response, Employee1POJO.class);
//
//String name1=empObj.getName();
//String job1=empObj.getJob();
//float salary1=empObj.getSalary();
//boolean isMarried1=empObj.isMarried();
//
//System.out.println(name1+"  "+job1+"  "+salary1+"  "+isMarried1);


Employee1POJO empObj = obj.readValue(Response, Employee1POJO.class);

System.out.println("Deserialized Response:");
System.out.println("Name: " + empObj.getName());
//System.out.println("Job: " + empObj.getJob());
//System.out.println("Salary: " + empObj.getSalary());
//System.out.println("Married: " + empObj.isMarried());





		
		
		

	}

}
