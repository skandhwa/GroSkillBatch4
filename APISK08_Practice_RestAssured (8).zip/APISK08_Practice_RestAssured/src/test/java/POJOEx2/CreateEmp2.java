package POJOEx2;

public class CreateEmp2 {

	public static void main(String[] args) {
		
		EmployeeAddressPojo x=new EmployeeAddressPojo();
		x.setCity("Pune");
		x.setState("Maharastra");
		x.setPincode(800044);
		
		Employee2Pojo emp=new Employee2Pojo();
		emp.setJob("QA Manager");
		emp.setName("Harry");
		emp.setSalary(80000f);
		emp.setMarried(false);
		emp.setEmpAddress(x);
		
		
		

	}

}
