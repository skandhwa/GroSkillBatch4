package POJOEx5;

import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;

public class CreateEmployee5 {

	public static void main(String[] args) throws JsonProcessingException {
		
		
		List<String> landmark=new ArrayList<String>();
		landmark.add("ABC Sweets");
		landmark.add("GK Hotel");
		landmark.add("JK mall");
		
		HouseDetailsPOJO obj1=new HouseDetailsPOJO();
		obj1.setFlatNo(102);
		obj1.setStreet("MG road");
		obj1.setLandmark(landmark);
		
		
		EmpAddress5POJO empAddress=new EmpAddress5POJO();
		empAddress.setHdPojo(obj1);
		empAddress.setCity("pune");
		empAddress.setState("Maharastra");
		empAddress.setZip(700055);
		
		List<String> banks=new ArrayList<String>();
		banks.add("SBI");
		banks.add("HDFC");
		banks.add("RBL");
		
		
		Employee5POJO emp=new Employee5POJO();
		emp.setName("Harry");
		emp.setAge(35);
		emp.setSalary(90000f);
		emp.setEmpAddress(empAddress);
		emp.setBank(banks);
		
		ObjectMapper obj=new ObjectMapper();
		
		String empJSON=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp);
		

		RestAssured.baseURI="https://reqres.in/";
		
		
	String Response=	given().log().all()
			
		.header("content-type","application/json")
		.header("x-api-key","reqres-free-v1")
		.body(empJSON)
		
		.when().post("api/users")
		.then().log().all().
		
		assertThat().statusCode(201)
		.extract().response().asString();


	System.out.println(Response);
		
		
		
		
		
		
		
		
		
		

	}

}
