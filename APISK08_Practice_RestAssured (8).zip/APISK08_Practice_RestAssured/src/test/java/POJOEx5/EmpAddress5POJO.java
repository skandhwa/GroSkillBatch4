package POJOEx5;

public class EmpAddress5POJO {
	
	private HouseDetailsPOJO hdPojo;
	private int zip;
	private String state;
	private String city;
	
	
	public HouseDetailsPOJO getHdPojo() {
		return hdPojo;
	}
	public void setHdPojo(HouseDetailsPOJO hdPojo) {
		this.hdPojo = hdPojo;
	}
	public int getZip() {
		return zip;
	}
	public void setZip(int zip) {
		this.zip = zip;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	
	

}
