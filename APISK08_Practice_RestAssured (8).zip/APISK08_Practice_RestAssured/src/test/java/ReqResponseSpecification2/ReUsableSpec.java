package ReqResponseSpecification2;

import static io.restassured.RestAssured.given;

import java.util.LinkedHashMap;
import java.util.Map;

import Payload.PayloadData;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class ReUsableSpec {
	
	public static RequestSpecification getRequest()
	{
		
		String token="Bearer a682a89b74963538f47d3ec72b6af8f655ef7c20f8d1a7e3ad8582ffd8dfdf64";
		RequestSpecification req=new RequestSpecBuilder().
				setBaseUri("https://gorest.co.in")
				.setContentType(ContentType.JSON).
				setRelaxedHTTPSValidation().
				setBody(PayloadData.goRestPayload())
				
				.build();
		
		RequestSpecification respec= given().log().all().header("Authorization",token).
				spec(req);
		return respec;
		
		
	}
	
	public static ResponseSpecification getResponse(int statuscode)
	{
		ResponseSpecification res=new ResponseSpecBuilder()
				.expectStatusCode(statuscode).build();
		
		return res;
	}

}
