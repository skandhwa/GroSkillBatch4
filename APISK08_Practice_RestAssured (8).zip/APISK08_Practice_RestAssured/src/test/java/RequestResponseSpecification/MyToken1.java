package RequestResponseSpecification;

public class MyToken1 {
	
	public static String Token()
	{
		String token="Bearer a682a89b74963538f47d3ec72b6af8f655ef7c20f8d1a7e3ad8582ffd8dfdf64";
		return token;
	}
	

}
