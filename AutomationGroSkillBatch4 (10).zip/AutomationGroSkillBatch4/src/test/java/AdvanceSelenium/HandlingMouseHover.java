package AdvanceSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class HandlingMouseHover {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demoqa.com/menu/#");
		driver.manage().window().maximize();
		Actions act=new Actions(driver);	
	WebElement ele=	driver.findElement(By.xpath("//a[text()='Main Item 2']"));
		
	act.moveToElement(ele).build().perform();
	Thread.sleep(3000);
	//driver.findElement(By.xpath("(//a[text()='Sub Item'])[1]")).click();
	
WebElement ele2=	driver.findElement(By.xpath("//*[text()='SUB SUB LIST »']"));
	act.moveToElement(ele2).build().perform();	


	}

}
