package AdvanceSelenium;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HandlingWaits {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		
		
		//IMPLICIT WAIT
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		///Explicit wait 
		
		WebDriverWait x=new WebDriverWait(driver,Duration.ofSeconds(10));
		
	WebElement ele=	x.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#Skills")));
		
		////Fluent Wait 
	
	FluentWait y=new FluentWait(driver);
	y.withTimeout(Duration.ofSeconds(10));
	y.pollingEvery(Duration.ofSeconds(2));
	y.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("css1")));
	y.until(ExpectedConditions.elementToBeClickable(By.xpath("xpath1")));
	y.ignoring(NoSuchElementException.class);

	}

}
