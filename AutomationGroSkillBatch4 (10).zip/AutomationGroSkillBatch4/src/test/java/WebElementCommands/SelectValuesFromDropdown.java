package WebElementCommands;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SelectValuesFromDropdown {

	public static void main(String[] args) throws InterruptedException {
		

		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//select[@id='Skills']"));
		
	Select oselect=new Select(ele);
	
	List<WebElement> li=oselect.getOptions();
	
	for(int i=0;i<li.size();i++)///i=0,0<
	{
	String values=	li.get(i).getText();//li.get(0).
	System.out.println(values);
	
	
	}
	boolean flag=false;
     for (WebElement option : li) {
         if (option.getText().equals("Android")) {
             flag= true;
             break;
         }
     }

     System.out.println("Does the list contain Android? " + flag);

     Thread.sleep(5000);
     driver.quit();

	}

}
