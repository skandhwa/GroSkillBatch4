package AdvanceSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class HandlingCopyPasteOperation {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demoqa.com/text-box");
		driver.manage().window().maximize();
		driver.findElement(By.cssSelector("#userName")).sendKeys("Saurabh");
		driver.findElement(By.cssSelector("#userEmail")).sendKeys("sk123@gmail.com");
		driver.findElement(By.cssSelector("#currentAddress")).sendKeys("Tara Regency ,Circular road,MG chowk,Mumbai");
		Actions act=new Actions(driver);
		
		///Select the entire content
		
		act.keyDown(Keys.CONTROL);
		act.sendKeys("a");		
		act.keyUp(Keys.CONTROL);
		act.build().perform();
		
		////Copy the entire content
		
		act.keyDown(Keys.CONTROL);
		act.sendKeys("c");
		act.keyUp(Keys.CONTROL);
		act.build().perform();
		
		///Press the tab button
		
		act.sendKeys(Keys.TAB);
		act.build().perform();
		Thread.sleep(3000);
		
		
		///paste the content
		
WebElement ele=driver.findElement(By.xpath("//*[@id='permanentAddress']"));
		
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].style.border='5px solid red'",ele);
		
		Thread.sleep(3000);
		
		
		act.keyDown(Keys.CONTROL);
		act.sendKeys("v");
		act.keyUp(Keys.CONTROL);
		act.build().perform();
		
		
		
		

	}

}
