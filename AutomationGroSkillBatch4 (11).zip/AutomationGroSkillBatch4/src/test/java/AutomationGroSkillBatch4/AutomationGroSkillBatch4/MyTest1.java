package AutomationGroSkillBatch4.AutomationGroSkillBatch4;

interface X5
{
	void test();
}

class C4 
{
	
}

class C5 extends C4 implements X5
{
	public void test()
	{
		
	}
}






public class MyTest1 {

	public static void main(String[] args) {
		

	}

}
