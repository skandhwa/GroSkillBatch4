package WebElementCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class HandlingDropdownSelectClassExample {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.id("Skills"));
	
	Select obj=new Select(ele);
	//obj.selectByIndex(6);
	//obj.selectByVisibleText("Client Support");
	obj.selectByValue("Data Analytics");
	 Thread.sleep(5000);
	 
	WebElement ele2= driver.findElement(By.xpath("//div[@class='ui-autocomplete-multiselect ui-state-default ui-widget']"));
	
	
	
	
	
    Thread.sleep(5000);
    driver.quit();
    
    
    
	
	
	
	
	
		

	}

}
