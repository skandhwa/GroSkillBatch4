package AdvanceSelenium;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class DownloadCustomLocation {

	public static void main(String[] args) throws InterruptedException {
		
		 ChromeOptions options = new ChromeOptions();
		 String downloadPath = "D:\\TestFiles\\MyFiles";

	        Map<String, Object> prefs = new HashMap<>();
	        prefs.put("download.default_directory", downloadPath);
	        prefs.put("download.prompt_for_download", false); // optional to avoid popup
	        options.setExperimentalOption("prefs", prefs);
		
		WebDriver driver=new ChromeDriver(options);
		driver.manage().window().maximize();
		 driver.get("https://www.learningcontainer.com/sample-pdf-files/");

		 JavascriptExecutor js=(JavascriptExecutor)driver;
			js.executeScript("window.scrollBy(0,1800)");
			Thread.sleep(5000);
		 
         // Click the download button (Sample PDF)
         driver.findElement(By.xpath("(//a[text()='Download'])[1]")).click();

         System.out.println("PDF download started from learningcontainer.com");

        System.out.println("E2E Execution Completed! Check folder: " + downloadPath);
		

	}

}
