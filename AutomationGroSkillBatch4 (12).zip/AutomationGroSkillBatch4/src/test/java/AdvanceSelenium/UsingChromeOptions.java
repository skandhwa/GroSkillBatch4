package AdvanceSelenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class UsingChromeOptions {

	public static void main(String[] args) throws InterruptedException {
		
		 ChromeOptions options = new ChromeOptions();
		
		 options.addArguments("--incognito");            // Open browser in incognito
		 options.addArguments("--start-maximized");
		// Maximize window
		 options.addArguments("--disable-infobars");     // Disable "Chrome is being controlled"
		 options.addArguments("--disable-notifications");// Disable notification popups
		 options.addArguments("--disable-popup-blocking");
		//options.addArguments("--headless=new");
		 options.addArguments("--window-size=1920,1080");
		// options.addArguments("--ignore-certificate-errors");
		 WebDriver driver = new ChromeDriver(options);
		 driver.get("https://www.hyrtutorials.com/p/calendar-practice.html");
		 Thread.sleep(3000);
		String title= driver.getTitle();
		System.out.println("Title of the page is  "+title);
		
		driver.quit();
		 

	}

}
