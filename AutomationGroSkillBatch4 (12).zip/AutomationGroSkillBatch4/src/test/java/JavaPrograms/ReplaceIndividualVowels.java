package JavaPrograms;

public class ReplaceIndividualVowels {

	public static void main(String[] args) {
		
		
		String str ="tip tap toe";
		
		char []ch=str.toCharArray();  /// @
		
		for(char x:ch)
		{
			if(x=='a' || x=='e' || x=='i' || x=='o' || x=='u')
			{
			  
			}
		}

	}

}
