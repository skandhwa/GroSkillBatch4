package JavaPrograms;	

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ReverseIndividualWords {

	public static void main(String[] args) {
		
		String str="java selenium python";
		StringBuilder sb=new StringBuilder();
		
		String []s=str.split(" ");
		for(String x:s)
		{
			List<Character> li=new ArrayList<Character>();
			for(Character y:x.toCharArray())
			{
				li.add(y);
			}
			Collections.sort(li);
			
			StringBuilder revword=new StringBuilder();
			for(char y:li)
			{
				revword.append(y);
			}
			sb.append(revword).append(" ");
			
		}
		
		System.out.println(sb.toString());
		
		

	}

}
