package JavaPrograms;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SortWordNew {

	public static void main(String[] args) {
		
String sentence = "sorting characters in each word";
        
      
        String[] words = sentence.split(" ");
        
       
        StringBuilder sortedSentence = new StringBuilder();
        
        for (String word : words) {
           
            ArrayList<Character> charList = new ArrayList<>();
            for (char c : word.toCharArray()) {
                charList.add(c);
            }
            
           
            Collections.sort(charList);
            
            
            StringBuilder sortedWord = new StringBuilder();
            for (char c : charList) {
                sortedWord.append(c);
            }
            
           
            sortedSentence.append(sortedWord).append(" ");
        }
        
       
        System.out.println("Sentence with sorted characters in each word:");
        System.out.println(sortedSentence.toString());
       
	}	

	}

