package JavaPrograms;

public class StringSortWord {

	public static void main(String[] args) {
		 String str = "java is a programming language";
	        String[] words = str.split(" ");
	        StringBuilder result = new StringBuilder();
	        for (String word : words) {
	            char[] chars = word.toCharArray();
	            java.util.Arrays.sort(chars);   // sort characters
	            result.append(new String(chars)).append(" ");
	        }
	        System.out.println(result.toString().trim());

	}

}
