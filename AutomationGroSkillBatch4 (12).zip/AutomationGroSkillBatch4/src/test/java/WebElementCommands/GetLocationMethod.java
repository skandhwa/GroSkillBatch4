package WebElementCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetLocationMethod {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		WebElement ele=driver.findElement(By.xpath("(//input[@type='text'])[1]"));
		
		Point p=ele.getLocation();
		
		System.out.println("Coordinates are  "+p.x +"   "+p.y  );
		

	}

}
