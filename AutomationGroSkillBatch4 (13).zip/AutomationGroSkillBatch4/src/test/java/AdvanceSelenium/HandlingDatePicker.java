package AdvanceSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingDatePicker {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        driver.get("https://www.hyrtutorials.com/p/calendar-practice.html");

        // ===== TARGET DATE =====
        String targetDay = "31";
        String targetMonth = "March";
        String targetYear = "2040";
        JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,2300)"," ");
		Thread.sleep(5000);

        // Open the calendar
        driver.findElement(By.id("sixth_date_picker")).click();

        while (true) {
            // Read current month and year
            String month = driver.findElement(By.className("ui-datepicker-month")).getText();
            String year = driver.findElement(By.className("ui-datepicker-year")).getText();

            // If month & year match → stop looping
            if (month.equals(targetMonth) && year.equals(targetYear)) {
                break;
            }

            // Click the NEXT button
            driver.findElement(By.xpath("//span[text()='Next']")).click();
        }

        // Select the date
        driver.findElement(By.xpath("//a[text()='" + targetDay + "']")).click();

        // Print the selected date
        String selectedDate = driver.findElement(By.id("first_date_picker")).getAttribute("value");
        System.out.println("Selected Date: " + selectedDate);

        driver.quit();

	}

}
