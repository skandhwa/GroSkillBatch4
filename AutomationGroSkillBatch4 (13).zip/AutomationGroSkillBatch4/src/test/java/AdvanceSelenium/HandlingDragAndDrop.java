package AdvanceSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class HandlingDragAndDrop {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Static.html");
		driver.manage().window().maximize();
		Actions act=new Actions(driver);
		
		WebElement src1= driver.findElement(By.xpath("(//img[@id='angular'])[1]"));
		WebElement src2= driver.findElement(By.xpath("(//img[@id='mongo'])[1]"));
		WebElement src3= driver.findElement(By.xpath("(//img[@id='node'])[1]"));
		
		WebElement target= driver.findElement(By.xpath("//div[@id='droparea']"));
		
		//act.dragAndDrop(src1, target).build().perform();
		act.dragAndDropBy(src1, 50, 100).build().perform();
		
		
		Thread.sleep(3000);
		act.dragAndDrop(src2, target).build().perform();
		Thread.sleep(3000);
		act.dragAndDrop(src3, target).build().perform();
	}

}
