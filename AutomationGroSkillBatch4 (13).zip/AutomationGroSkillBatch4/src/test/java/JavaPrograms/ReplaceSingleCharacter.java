package JavaPrograms;

public class ReplaceSingleCharacter {

	public static void main(String[] args) {
		
		String str="Tomorrow";
		int count=3;
		
		char []ch=str.toCharArray();
		
		char toreplace='o';
		
		String replacementString ="$";
		
		StringBuilder sb=new StringBuilder();
		
		for(char x:ch)
		{
			if(x==toreplace)
			{
				sb.append(replacementString.repeat(count));
				count --;
			}
			
			else
			{
				sb.append(x);
			}
		}
		
		System.out.println(sb.toString());
		
		
		
		

	}

}
