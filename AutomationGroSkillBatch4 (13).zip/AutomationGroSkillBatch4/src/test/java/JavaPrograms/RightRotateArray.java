package JavaPrograms;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RightRotateArray {

	public static void main(String[] args) {
		  int[] a = {10, 20, 30, 40, 50};

		  List<Integer> li=new ArrayList<Integer>();
		  for(Integer x:a)
		  {
			  li.add(x);
		  }
		  
		  Collections.rotate(li, -2);
		  
		  for(Integer y:li)
		  {
			  System.out.print(y +"  ");
		  }
		  
		  
		  
		  
		  

	}

}
