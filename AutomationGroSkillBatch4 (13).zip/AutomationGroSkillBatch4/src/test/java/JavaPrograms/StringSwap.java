package JavaPrograms;

public class StringSwap {

	public static void main(String[] args) {

		String str1 ="ABC";
		
		String str2="DEF";
		
		str1 =str1+str2;
		
		int x= str1.length(); ///6
		
		int y= str2.length(); ////3
		
		str2=    str1.substring(0,x-y);////str1.substring(0,3)///ABCDEF.substring(0,3)
		
		str1 =str1.substring(y);
		
		System.out.println(str1);
		System.out.println(str2);
		
		


	}

}
