package AdvanceSelenium;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class HandlingAlerts {

	public static void main(String[] args) throws InterruptedException {
		
		String str2="Harry";
		ChromeOptions options = new ChromeOptions();
		 options.addArguments("--disable-infobars");     // Disable "Chrome is being controlled"
		 options.addArguments("--disable-notifications");// Disable notification popups
		 options.addArguments("--disable-popup-blocking");
		
		WebDriver driver=new ChromeDriver(options);
		driver.get("https://demo.automationtesting.in/Alerts.html");
		driver.manage().window().maximize();
		
		
		///SIMPLE ALERTS
		
		
//		driver.findElement(By.xpath("//button[@class='btn btn-danger']")).click();
//
//		
//		Thread.sleep(3000);
//		driver.switchTo().alert().accept();
		
		
		
		//Confirmation Alerts
		
//		driver.findElement(By.xpath("//a[@href='#CancelTab']")).click();
//		
//		driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
//		Thread.sleep(3000);
//		driver.switchTo().alert().accept();
		
		///Prompt alerts
		
		driver.findElement(By.xpath("//a[@href='#Textbox']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[@class='btn btn-info']")).click();
		Thread.sleep(3000);
		
		Alert alert=driver.switchTo().alert();
		Thread.sleep(3000);
		alert.sendKeys(str2);
		Thread.sleep(3000);
		alert.accept();
		
	String Value=	driver.findElement(By.cssSelector("#demo1")).getText();
		
	if(Value.contains(str2))
	{
		System.out.println("TC pass");
	}
	
	else
	{
		System.out.println("TC failed");
	}
	
		
		
		
		
		
		
	}

}
