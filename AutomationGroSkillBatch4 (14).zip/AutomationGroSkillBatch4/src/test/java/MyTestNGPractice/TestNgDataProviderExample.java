package MyTestNGPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestNgDataProviderExample {
	
	WebDriver driver;
	
	@DataProvider(name="dp1")

	public Object[][] dpMethod()
	{
	return new Object[][]
	{
	{"Java"},{"Selenium"},{"Playwright testing"}
	};
	}
	
	@Test(dataProvider="dp1")
	public void searchGoogle(String x) throws InterruptedException
	{
		driver=new ChromeDriver();
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//textarea[@jsname='yZiJbe']"));
		ele.sendKeys(x);
		driver.findElement(By.xpath("//div[@jsmodel='b5W85 vNzKHd']")).click();
		Thread.sleep(3000);
		ele.sendKeys(Keys.ENTER);
		Thread.sleep(3000);
		driver.quit();
		
	}
	
	
	
	

}
