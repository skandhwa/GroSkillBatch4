package MyTestNGPractice;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class TestNgParameters {
	
	@Test
	@Parameters({"a","b","c"})
	
	public void sum(int x,int y,int z)
	{
		int r=x+y+z;
		System.out.println(r);
	}
	
	
	@Test
	@Parameters({"a","b"})
	
	public void diff(int x,int y)
	{
		int r=x-y;
		System.out.println(r);
	}
	
	
	
	@Test
	@Parameters({"a","b","c"})
	
	public void mul(int x,int y,int z)
	{
		int r=x*y*z;
		System.out.println(r);
	}
	

}
