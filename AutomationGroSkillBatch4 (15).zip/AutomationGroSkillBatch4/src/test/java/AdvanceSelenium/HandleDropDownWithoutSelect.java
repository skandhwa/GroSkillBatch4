package AdvanceSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandleDropDownWithoutSelect {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

     

        driver.get("https://demoqa.com/select-menu");

        Thread.sleep(2000);

        JavascriptExecutor js = (JavascriptExecutor) driver;

        // Scroll down to dropdown
        js.executeScript("window.scrollBy(0, 300);");
        Thread.sleep(1000);

        // 1️⃣ Locate the custom React dropdown
        WebElement dropdown = driver.findElement(By.xpath("//div[@id='withOptGroup']"));

        // Click dropdown using JavaScript Executor
        js.executeScript("arguments[0].click();", dropdown);
        Thread.sleep(1000);

        // 2️⃣ Locate option "Group 2, option 1"
        WebElement option = driver.findElement(By.xpath("//div[contains(text(),'Group 2, option 1')]"));

        // Click option using JavaScript
        js.executeScript("arguments[0].click();", option);
        Thread.sleep(1000);

        System.out.println("Successfully selected option from React dropdown using JS!");

        // Close browser
        driver.quit();

	}

}
