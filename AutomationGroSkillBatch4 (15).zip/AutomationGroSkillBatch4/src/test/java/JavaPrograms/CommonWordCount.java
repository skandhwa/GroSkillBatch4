package JavaPrograms;

import java.util.ArrayList;
import java.util.List;

public class CommonWordCount {

	public static void main(String[] args) {

		 String str = "java java program is";

	        String[] s = str.split(" ");

	        List<String> li = new ArrayList<String>();

	        for (int i = 0; i < s.length; i++) {
	            for (int j = i + 1; j < s.length; j++) {
	                if (s[i].equals(s[j]) && !li.contains(s[i])) {
	                    li.add(s[i]);
	                }
	            }
	        }

	        System.out.println(li);
	        System.out.println(li.size());
        
        
        
        
        

	}

}
