package MyTestNGPractice;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class MyTest1 {
	
	@BeforeSuite
	public void test1()
	{
		System.out.println("I am before suite");///1
	}
	
	@Test
	public void Ctest2()
	{
		System.out.println("I am C test method");///4
	}
	
	
	
	
	@Test
	public void Dtest2()
	{
		System.out.println("I am D test method");///4
	}
	
	@BeforeTest
	public void test3()
	{
		System.out.println("I am before test method");///2
	}
	
	
	@AfterMethod
	public void test4()
	{
		System.out.println("I am AfterMethod ");//5
	}
	
	
	
	@AfterSuite
	public void test5()
	{
		System.out.println("I am After Suite");//7
	}
	
	
	@AfterClass
	public void test6()
	{
		System.out.println("I am After class ");//6
	}
	
	
	@BeforeMethod
	public void test7()
	{
		System.out.println("I am after method");//3
	}
	
	
	

}
