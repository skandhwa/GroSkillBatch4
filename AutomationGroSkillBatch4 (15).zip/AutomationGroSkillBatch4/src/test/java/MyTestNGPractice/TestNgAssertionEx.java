package MyTestNGPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class TestNgAssertionEx {
	
	@Test(enabled=false)
	
	public void validate()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		String title=driver.getTitle();
		//Assert.assertEquals(title, "Google");
		
		Assert.assertNotEquals(title, "Google123");
		Reporter.log("My Test Case failed");
		
		
		
		
	}
	
	@Test
	public void Assertion2()
	{
		int x=10;
		int y=5;
		//Assert.assertTrue(x<y);
		Assert.assertFalse(x<y);
		String str=null;
		Assert.assertNotNull(str);
		Reporter.log("My Test Case failed");
		
		
		
		
	}
	
	
	
	
	
	

}
