package MyTestNGPractice;

import org.testng.annotations.Ignore;
import org.testng.annotations.Test;



public class TestNgEnabledEx {

	@Test
	public void show()
	{
		System.out.println("I am sanity 1");
	}
	
	@Test(alwaysRun=true,enabled=false)
	public void run()
	{
		System.out.println("I am sanity 2");
	}
	
	
	@Test
	public void test()
	{
		System.out.println("I am sanity 3");
	}
	
	
	
}
