package MyTestNGPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class TestNgParallelClasses1 {
	WebDriver driver;
	@Test
	public void AopenMyntra()
	{
		driver=new ChromeDriver();
		driver.get("https://www.myntra.com");
		driver.manage().window().maximize();
		
		
		
	}
	
	
	@Test
	public void BtestInstagram()
	{
		driver=new ChromeDriver();
		driver.get("https://www.instagram.com");
		driver.manage().window().maximize();
		
	}
	
	@Test
	public void CtestAmazon()
	{
		driver=new ChromeDriver();
		driver.get("https://www.amazon.com");
		driver.manage().window().maximize();
		
	}
	
	@AfterTest
	public void closeBrowser() throws InterruptedException
	{
		Thread.sleep(7000);
		driver.quit();
	}

}
