package MyTestNGPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class TestNgParallelClasses2 {

	WebDriver driver;
	@Test
	public void DopenGoogle()
	{
		driver=new ChromeDriver();
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
		
		
		
	}
	
	@Test
	public void Etestmeesho()
	{
		driver=new ChromeDriver();
		driver.get("https://www.ajio.com");
		driver.manage().window().maximize();
		
	}
	
	@Test
	public void FtestFacebook()
	{
		driver=new ChromeDriver();
		driver.get("https://www.facebook.com");
		driver.manage().window().maximize();
		
	}
	
	
	@AfterTest
	public void closeBrowser() throws InterruptedException
	{
		Thread.sleep(7000);
		driver.quit();
	}
	
	
	
	
	
}
