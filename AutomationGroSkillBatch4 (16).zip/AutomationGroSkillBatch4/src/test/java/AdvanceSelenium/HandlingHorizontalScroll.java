package AdvanceSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class HandlingHorizontalScroll {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		Actions act=new Actions(driver);
		//WebElement ele=driver.findElement(By.xpath("//iframe[@id='google_esf']"));
		
		
		
		for(int i=0;i<5;i++)
		{
			act.sendKeys(Keys.RIGHT).build().perform();
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
