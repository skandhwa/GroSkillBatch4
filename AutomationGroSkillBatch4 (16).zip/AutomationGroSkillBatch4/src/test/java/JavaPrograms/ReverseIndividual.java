package JavaPrograms;

import java.util.ArrayList;
import java.util.Collections;

public class ReverseIndividual {

	public static void main(String[] args) {
		
		
		String str= "tip tap toe";
		
		StringBuilder sb=new StringBuilder();
		
		String []s= str.split(" ");
		
		for(String x:s)
		{
			ArrayList<Character> li=new ArrayList<Character>();
			
			for(Character y:x.toCharArray())
			{
				li.add(y);
			}
			
			Collections.reverse(li);
			
			StringBuilder revword=new StringBuilder();
			
			for(char z:li)
			{
				revword.append(z);
			}
			
			sb.append(revword).append(" ");
			
			
		}
		
		System.out.println(sb.toString());
		

	}

}
