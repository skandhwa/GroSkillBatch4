package JavaPrograms;

import java.util.ArrayList;
import java.util.Collections;

public class SortingIndividualCharacters {

	public static void main(String[] args) {
		
		String str="tip tap toe";/// pit pat eot
		
		//// aajv  is  a  agi  aae
		
		String []word= str.split(" ");
		
		StringBuilder sb=new StringBuilder();
		
		
		
		for(String x:word)
		{
			ArrayList<Character> li=new ArrayList<Character>();
			for(char c: x.toCharArray())
			{
				li.add(c);
			}
			
			Collections.sort(li);
			
			StringBuilder sortedWord=new StringBuilder();
			for(char c:li)
			{
				sortedWord.append(c);
			}
			
			sb.append(sortedWord).append(" ");
			
		}
		
		System.out.println("Sorted Sentence is    "+sb);
		
		
		
		
		
		
		

	}

}
