package JavaScriptExecutorEx;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingClickOp {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		
		JavascriptExecutor js=(JavascriptExecutor)driver;
		
		WebElement ele=driver.findElement(By.xpath("//input[@id='checkbox1']"));
		
		WebElement ele1=driver.findElement(By.xpath("//input[@value='Male']"));
		
		Thread.sleep(3000);
		js.executeScript("arguments[0].click(),arguments[1].click()",ele,ele1);
		
		
		
	}

}
