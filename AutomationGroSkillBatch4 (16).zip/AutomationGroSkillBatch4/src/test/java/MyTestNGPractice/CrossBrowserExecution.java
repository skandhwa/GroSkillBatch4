package MyTestNGPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class CrossBrowserExecution {
	
	public static WebDriver driver;
	
	@Parameters("browser")
	
	@BeforeMethod
	public void openBrowser(String browser) throws InterruptedException
	{
		if(browser.equalsIgnoreCase("firefox"))
		{
			driver=new FirefoxDriver();
			Thread.sleep(5000);
		}
		
		else if(browser.equalsIgnoreCase("chrome"))
		{
			driver=new ChromeDriver();
		}
		
		else if(browser.equalsIgnoreCase("edge"))
		{
			driver=new EdgeDriver();
		}
		
		
	}
	
	
	@Test
	public void run()
	{
		
		driver.get("https://www.google.com");
		String title=driver.getTitle();
		driver.manage().window().maximize();
		
		
		Assert.assertNotEquals(title, "Google123");
		Reporter.log("My Test Case passed");
		
	}
}
