package MyTestNGPractice;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(value=MyTestNGPractice.MyListener1.class)

public class MyListenerCallTest 
{
	WebDriver driver1=DriverInitialization.initializeDriver();
	@Test
	public void test1()
	{
		driver1.get("https://www.google.com");
		String title=driver1.getTitle();
		Assert.assertEquals(title, "Google");
	}
	
	
	@Test(priority=0)
	public void login()
	{
		
		System.out.println("Login Successfull");
		int x=9/3;
		System.out.println(x);
	}
	
	@Test(dependsOnMethods= {"login"},priority=1)
	public void SearchProduct()
	{
		System.out.println("SP Successfull");
	}
	
	
	
	
	
	

}
