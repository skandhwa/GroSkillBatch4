package MyTestNGPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestNgDPEx2 {

WebDriver driver;
	
	@DataProvider(name="dp1")

	public Object[][] dpMethod()
	{
	return new Object[][]
	{
	{"mngr647967","sUgYzub"}
	};
	}
	
	
	@Test(dataProvider="dp1")
	public void test(String uname,String password) throws InterruptedException
	{
		driver=new ChromeDriver();
		driver.get("https://demo.guru99.com/V4/index.php");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//input[@name='uid']")).sendKeys(uname);
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(password);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@type='submit']")).click();
	String title=	driver.getTitle();
	System.out.println(title);
		
	}

}



