package MyTestNGPractice;

import org.testng.annotations.Test;

public class TestNgDependsOn 
{

	@Test(priority=0)
	public void login()
	{
		
		System.out.println("Login Successfull");
	}
	
	@Test(dependsOnMethods= {"login"},priority=1)
	public void SearchProduct()
	{
		System.out.println("SP Successfull");
	}
	
	
	
	@Test(dependsOnMethods= {"login","SearchProduct"},priority=2)
	public void AddToCart()
	{
		System.out.println("AC Successfull");
	}
	
	
	
	@Test(dependsOnMethods= {"login","SearchProduct","AddToCart"},priority=3)
	public void PaymentGateway()
	{
		int x=9/0;
		System.out.println(x);
		System.out.println("PG Successfull");
	}
	
	
	
	@Test(alwaysRun=true,dependsOnMethods= {"login","SearchProduct","AddToCart","PaymentGateway"},priority=4)
	public void logout()
	{
		System.out.println("Logout Successfull");
	}
	
	
	
	

}
