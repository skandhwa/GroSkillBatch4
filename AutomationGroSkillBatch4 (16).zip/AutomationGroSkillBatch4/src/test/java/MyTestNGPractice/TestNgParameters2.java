package MyTestNGPractice;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class TestNgParameters2 {
	
	
	@Test
	@Parameters({"a","b"})
	
	public void div(int x,int y)
	{
		int r=x/y;
		System.out.println(r);
	}

}
