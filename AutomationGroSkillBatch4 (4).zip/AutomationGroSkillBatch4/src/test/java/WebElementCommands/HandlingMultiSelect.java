package WebElementCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class HandlingMultiSelect {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.techlistic.com/p/selenium-practice-form.html#google_vignette");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//select[@id='selenium_commands']"));
	
	
		Select obj1=new Select(ele);
		boolean flag=obj1.isMultiple();
		
		if(flag==true)
		{
			obj1.selectByIndex(1);
			obj1.selectByIndex(2);
			obj1.selectByIndex(3);
		}
		
		

	}

}
