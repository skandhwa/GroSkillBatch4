package WebElementCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class BooleanMethods2 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
		driver.manage().window().maximize();
		Thread.sleep(5000);
		
	WebElement ele=	driver.findElement(By.xpath("(//input[@type='radio'])[1]"));
	
	if(ele.isSelected()==false && ele.isDisplayed()==true && ele.isEnabled()==true)
	{
		ele.click();
	}
	
	else
	{
		System.out.println("Element is already selected");
	}

	driver.findElement(By.xpath("//input[@value='Login']")).submit();
	
	
	}
	

	
	

}
