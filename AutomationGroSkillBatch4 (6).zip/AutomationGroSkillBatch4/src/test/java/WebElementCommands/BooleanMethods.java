package WebElementCommands;

import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class BooleanMethods {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
		driver.manage().window().maximize();
		
		
		try
		{
		WebElement ele=	driver.findElement(By.xpath("//input[@placeholder='XXXXXXYYYYYY']"));
		
		
		if(ele.isDisplayed()==true && ele.isEnabled()==true)
		
			ele.sendKeys("Saurabh");
		
		
		
		}
		
		catch(Exception e)
		{
			System.out.println("Caught with  "+e.getMessage());
		}
		
		
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//input[@id='gender'])[1]")).click();
		
		driver.findElement(By.id("email")).sendKeys("abcd@gmail.com");
		
		Thread.sleep(3000);
		
		driver.quit();
		
		
		
		
		

	}

}
