package AdvanceSelenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingFramesEx {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Frames.html");
	List<WebElement> li=	driver.findElements(By.tagName("a"));
	
	int x=li.size();
	System.out.println("The total links are  "+x);
	
	
   List<WebElement> li2=	driver.findElements(By.tagName("iframe"));
		
   System.out.println("The total number of frames are  "+li2.size());
		
		
		
		
		
		driver.manage().window().maximize();
	//	driver.findElement(By.xpath("(//input[@type='text'])[1]")).sendKeys("Saurabh");
		
		driver.switchTo().frame("singleframe");
		
		//driver.switchTo().frame("SingleFrame");
		
		driver.findElement(By.xpath("(//input[@type='text'])[1]")).sendKeys("Saurabh");
		driver.switchTo().defaultContent();

		driver.findElement(By.xpath("//a[@href='#Multiple']")).click();
		
		
		
	}

}
