package HandlingDynamicTable;

import java.util.List;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class DynamicWebTable {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://cosmocode.io/automation-practice-webtable/");
		driver.manage().window().maximize();

		
		
		String before_xpath="//*[@id='countries']/tbody/tr[ ";
		
		String after_xpath="]/td[2]";
		
		
		
		String beforexpath_chBox="//*[@id='countries']/tbody/tr[";
		String afterxpath_chBox="]/td[1]/input";
		
		
	List<WebElement> li=	driver.findElements(By.tagName("tr"));
	
	int x=li.size();
	System.out.println("Total Countries are   "+x);
	

	
	
	///Print all the country names
	
	System.out.println("List of all countries are \n");
	
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the country you want to select   ");
	String countryName=sc.nextLine();
	
	
	for(int i=2;i<x;i++)
	{
	String country=	driver.findElement(By.xpath(before_xpath+i+after_xpath)).getText();
	System.out.println(country);
	
	if(country.equalsIgnoreCase(countryName))
	{
		System.out.println(countryName +"  "+"is present");
		driver.findElement(By.xpath(beforexpath_chBox+i+afterxpath_chBox)).click();
		
		
	}
	
	}
	
	driver.findElement(By.xpath("//*[text()='Omani Rial']//parent::tr/td[1]//input")).click();
	
	
List<WebElement> li2=	driver.findElements(By.xpath("//*[contains(text(),'English')]"));
	
	System.out.println("Total Number of Countries using english as language   "+li2.size());
	 
	
	
	
	
		
		
		
		
		
		
		

	}

}
