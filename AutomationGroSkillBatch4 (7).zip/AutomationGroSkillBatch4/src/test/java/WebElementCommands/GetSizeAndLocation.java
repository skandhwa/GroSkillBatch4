package WebElementCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetSizeAndLocation {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		
		WebElement ele=	driver.findElement(By.xpath("(//input[@type='text'])[1]"));
		
		Dimension dim=ele.getSize();
		System.out.println("Height is  "+dim.height);
		System.out.println("Width is  "+dim.width);
		
		
		

	}

}
