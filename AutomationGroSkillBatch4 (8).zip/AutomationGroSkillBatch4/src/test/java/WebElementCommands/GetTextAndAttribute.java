package WebElementCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetTextAndAttribute {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.techlistic.com/p/selenium-practice-form.html#google_vignette");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//span[@style='font-size:large']"));
	String pageTitle=	ele.getText();
	System.out.println("Menu for page is  "+pageTitle);
	
	
		
		
		

	}

}
