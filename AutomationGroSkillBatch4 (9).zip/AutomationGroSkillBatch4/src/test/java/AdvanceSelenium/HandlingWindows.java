package AdvanceSelenium;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingWindows {

	public static void main(String[] args) {
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Windows.html");
		driver.manage().window().maximize();
		
	String WindowID=	driver.getWindowHandle();///A
	System.out.println("Window ID is  "+WindowID);
	
	driver.findElement(By.xpath("//button[@class='btn btn-info']")).click();
	
	
//	String WindowID2=	driver.getWindowHandle();
//	System.out.println("Window ID is  "+WindowID2);
	
	
	System.out.println("Printing all the Window IDS opened on the webpage");
	
Set<String> windowIDS=	driver.getWindowHandles();

System.out.println(windowIDS);

String title=driver.getTitle();

System.out.println("The title of the page is  "+title);

Iterator<String> itr= windowIDS.iterator();///A,B

while(itr.hasNext())
{
	String childWindowID=  itr.next();///Cw=B
	
	if(!WindowID.equals(childWindowID))
	{
		driver.switchTo().window(childWindowID);
		String title2=driver.getTitle();
		System.out.println(title2);
		
		driver.findElement(By.xpath("//a[text()='Register now!']")).click();
	}
	
	
	
}

//driver.close();

driver.switchTo().window(WindowID);

String title3= driver.getTitle();

System.out.println("Title of the main window again is  "+title3);


Set<String> mWindowIds= driver.getWindowHandles();

System.out.println(mWindowIds);













		

	}

}
