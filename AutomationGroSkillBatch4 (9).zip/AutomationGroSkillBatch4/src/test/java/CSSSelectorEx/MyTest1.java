package CSSSelectorEx;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MyTest1 {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demoqa.com/automation-practice-form");
		driver.findElement(By.cssSelector("#firstName")).sendKeys("Saurabh");
		
		//driver.findElement(By.cssSelector("#username")).sendKeys("008890");
		
	String Text=	driver.findElement(By.cssSelector("label[id='userName-label']")).getText();
		
		System.out.println(Text);
		

	}

}
