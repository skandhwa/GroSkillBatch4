package WebElementCommands;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class HandlingMultiSelect {

	public static void main(String[] args) throws InterruptedException {
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.techlistic.com/p/selenium-practice-form.html#google_vignette");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//select[@id='selenium_commands']"));
	
	
		Select obj1=new Select(ele);
		boolean flag=obj1.isMultiple();
		
		if(flag==true)
		{
			obj1.selectByIndex(1);
			obj1.selectByIndex(2);
			obj1.selectByIndex(3);
		}
		
		
		WebElement val=obj1.getFirstSelectedOption();
		System.out.println(val.getText());
		
		
	List<WebElement> li=	obj1.getAllSelectedOptions();
	for(int i=0;i<li.size();i++)
	{
		System.out.println(li.get(i).getText());
	}
	
	
	
	
		
		Thread.sleep(6000);
		
		obj1.deselectAll();
		obj1.deselectByIndex(2);
		obj1.deselectByValue("  ");
		
		obj1.deselectByVisibleText("  ");
		
		
		
		

	}

}
