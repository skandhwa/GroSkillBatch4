package StepDefinition11;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition11 {
	
	@Before
	public void beforeTest()
	{
		System.out.println("Connect to DB");
	}
	
	
	@After
	public void AfterTest()
	{
		System.out.println("Disconnect to DB");
	}
	
	@Before("@smoke")
	public void beforeSmoke()
	{
		System.out.println("I will run before smoke");
	}
	
	@After("@smoke")
	public void AfterSmoke()
	{
		System.out.println("I will run after smoke");
	}
	
	@Before("@e2e")
	public void beforeE2E()
	{
		System.out.println("I will run before e2e");
	}
	
	@After("@e2e")
	public void afterE2E()
	{
		System.out.println("I will run after E2E");
	}
	
	
	@Given("user opens the URL in the web browser")
	public void user_opens_the_url_in_the_web_browser() {
		
		System.out.println("Application launched");
	    
	}

	@Given("user enters the username in the uname textbox")
	public void user_enters_the_username_in_the_uname_textbox() {
		
		System.out.println("Username entered");
	    
	}

	@Given("user enters the password in the password textbox")
	public void user_enters_the_password_in_the_password_textbox() {
		
		System.out.println("password entered");
	    
	}

	@When("user hits on submit button of application")
	public void user_hits_on_submit_button_of_application() {
		
		System.out.println("Submit button clicked");
	   
	}

	@Then("user navigates to homepage of application")
	public void user_navigates_to_homepage_of_application() {
		
		System.out.println("user navigated to home page");
	   
	}
	
	@Given("user enters the {string} in the uname textbox")
	public void user_enters_the_in_the_uname_textbox(String string) {
		
		System.out.println("user enters uname");
	    
	}

	@Given("user enters the {string} in the password textbox")
	public void user_enters_the_in_the_password_textbox(String string) {
	   
		System.out.println("user enters pwd");
	}

	@When("the account is locked")
	public void the_account_is_locked() {
		
		System.out.println("account locked");
	    
	}

	@Then("an error message is being displayed")
	public void an_error_message_is_being_displayed() {
		
		System.out.println("error message displayed");
	   
	}
	
	
	@Given("user is on the home page of application")
	public void user_is_on_the_home_page_of_application() {
		
		System.out.println("user is on home page");
	    
	}

	@Given("user tries to search an item in search box")
	public void user_tries_to_search_an_item_in_search_box() {
		
		System.out.println("user search an item");
	    
	}

	@Given("user hits on search button")
	public void user_hits_on_search_button() {
	   
		
		System.out.println("user hits on search");
	}

	@Then("list of product is displayed")
	public void list_of_product_is_displayed() {
		
		System.out.println("product displayed");
	   
	}

	
	@Given("user hits electronics bar")
	public void user_hits_electronics_bar() {
	   
		System.out.println("electronics bar is shown");
	}

	@Then("list of electronic product is displayed")
	public void list_of_electronic_product_is_displayed() {
	    
		System.out.println("electronic product displayed");
		
	}
	
	
	@Given("user opens the demo application form in")
	public void user_opens_the_demo_application_form_in() {
	   
		System.out.println("application opnened");
	}

	@Given("user tries to enter below details")
	public void user_tries_to_enter_below_details(io.cucumber.datatable.DataTable userdetails) 
	{
	    WebDriver driver=new ChromeDriver();
	    driver.get("https://demo.automationtesting.in/Register.html");
	    driver.manage().window().maximize();
	    
	     List<List<String>> data=userdetails.asLists(String.class); 
	     
	     driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys(data.get(1).get(0));
	     driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys(data.get(1).get(1));
	     driver.findElement(By.xpath("//textarea[@rows=3]")).sendKeys(data.get(1).get(2));
	     driver.findElement(By.xpath("//input[@type='email']")).sendKeys(data.get(1).get(3));
	     
	     
	   
	     
	    
	}





}
