package AbstractionEx;

interface I1
{
     void display();
	void test();
	void message();
	int x=10;
	
}

class V4 implements I1
{
	public   void display()
	{
		System.out.println("hello");
	}
	
	public void test()
	{
		System.out.println("Hi");
	}
	
	public void message()
	{
		System.out.println("How r u");
	}
}


//class V5 implements I1
//{
//	public void message()
//	{
//		System.out.println("Hey");
//	}
//}


public class InterfaceEx1 {

	public static void main(String[] args) {
		
		I1 ref=new V4();
		ref.display();
		ref.test();
		ref.message();
		
		
		
		
		

	}

}
