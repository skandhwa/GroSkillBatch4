package AbstractionEx;

interface I12
{
	void display();
	void test();
		
	
}
interface I13 extends I12
{
	void message();
	void print();
}

class C13 implements I13
{
	public void display()
	{
		System.out.println("Hello");
	}
	
	public void message()
	{
		System.out.println("Hi");
	}
	
	public void print()
	{
		System.out.println("Java");
	}
	
	public void test()
	{
		System.out.println("Collections");
	}
}






public class interfaceExtends {

	public static void main(String[] args) {
		
		I13 abc=new C13();
		abc.display();
		abc.message();
		abc.test();
		abc.print();
		

	}

}
