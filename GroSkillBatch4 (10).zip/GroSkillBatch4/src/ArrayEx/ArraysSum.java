package ArrayEx;

public class ArraysSum {

	public static void main(String[] args) {
		
		int []a= {12,67,3,56,45};
		
		int sum=0;
		
		for(int i=1;i<a.length;i=i+2)//i=0,0<5//i=1,1<5
		{
			sum=sum+a[i];//sum=0+12=12//sum=12+67
		}
		
		System.out.println(sum);
		
		

	}

}
