package MyPack1;

class C12
{
	void A()
	{
		System.out.println("Hello");
	}
}

class C13 extends C12
{
	void B()
	{
		System.out.println("Hi");
	}
}




public class InheritanceEx1 {

	public static void main(String[] args) {
		
		C13 obj=new C13();
		obj.A();
		obj.B();
		

	}

}
