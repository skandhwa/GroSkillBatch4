package PolyMorphismAndKeywords;

class Employee
{
	int id;
	String empName;
	static String comName="CTS";
	
//	void change()
//	{
//		comName="Wipro";
//	}
//	
	
	
	Employee(int id, String empName)
	{
		this.id=id;
		this.empName=empName;
		
	}
	
	void display()
	{
		System.out.println(id+" "+empName+"  "+comName);
	}
	
	
	
	
}



public class StaticVariable {

	public static void main(String[] args) {
		
		Employee emp1=new Employee(1234,"Aniket");
		emp1.display();
		Employee emp2=new Employee(5234,"Mahesh");
		emp2.display();
		Employee emp3=new Employee(7234,"Harish");
		emp3.display();
		
		

	}

}
