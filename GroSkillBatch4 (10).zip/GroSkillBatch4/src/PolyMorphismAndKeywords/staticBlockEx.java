package PolyMorphismAndKeywords;

public class staticBlockEx {
	
	static
	{
		System.out.println("Hi");
	}

	public static void main(String[] args) {
		
		System.out.println("Hello");
		

	}

}
