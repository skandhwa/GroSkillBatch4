package StringDeclaration;

public class ArraySortLength {

	public static void main(String[] args) {
		
		
		String str="java is a language";
		
		String []a=str.split(" ");
		
		for(int i=0;i<a.length;i++)//i=0,0<4
		{
			for(int j=i+1;j<a.length;j++)//j=1,1<4
			{
				if(a[i].length()>a[j].length())///
				{
					String temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
			
			System.out.print(a[i].toString()+" ");
		}
		
		
		
	}

}
