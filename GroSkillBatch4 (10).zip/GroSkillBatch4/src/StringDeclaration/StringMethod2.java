package StringDeclaration;

public class StringMethod2 {

	public static void main(String[] args) {
		
		String str="Republic";
		
	char ch=	str.charAt(6);
	
	System.out.println("Value at index 6 is  "+ch);
		

	}

}
