package AbstractionEx;

abstract class V1
{
	abstract void test();
	
	void display()
	{
		System.out.println("Hello");
	}
	
	void message()
	{
		System.out.println("Hii");
	}
	
}

class V2 extends V1
{
	void test()
	{
		System.out.println("Hey");
	}
}






public class AbstractClass1Ex {

	public static void main(String[] args) {
		
		V2 obj=new V2();
		
		obj.test();
		obj.display();
		obj.message();
		

	}

}
