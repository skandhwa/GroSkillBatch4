package AbstractionEx;

interface I8
{
	void test();
	void display();
}

interface I9
{
	void message();
	void demo();
	
}

class X8 implements I8,I9
{
	public   void display()
	{
		System.out.println("hello");
	}
	
	
	
	public void test()
	{
		System.out.println("Hi");
	}
	
	public void message()
	{
		System.out.println("How r u");
	}
	
	public void demo()
	{
		System.out.println("Java");
	}
	
	void test1()
	{
		System.out.println("Selenium");
	}
}




public class MultipleInheritanceEx {

	public static void main(String[] args) {
		
		I8 ref=new X8();
		ref.test();
		ref.display();
		
		I9 ref1=new X8();
		ref1.message();
		ref1.demo();
		
		X8 obj=new X8();
		obj.test1();

	}

}
