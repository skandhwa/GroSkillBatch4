package AbstractionEx;

interface I6
{
	static void display()
	{
		System.out.println("Hello");
	}
}


public class StaticMethod_Interface {

	public static void main(String[] args) {
		
		I6.display();
		

	}

}
