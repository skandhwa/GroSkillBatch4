package ArrayEx;


class ArraySmallLarge
{
	public static int smallLarge(int []a,int total)
	{
		for(int i=0;i<a.length;i++)///i=0,0<4//i=1,1<4//i=2,2<4//i=3,3<4//i=4,4<4
		{
			for(int j=i+1;j<a.length;j++)///
			{
				if(a[i]>a[j])// a[2]>a[3]
				{
					int temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		
		return a[total-6];
	}
}



public class ArrayLargestSmallest {

	public static void main(String[] args) {
		
		int []a= {17,4,9,2,14,1};
		
		int x=a.length;
		
	int number=	ArraySmallLarge.smallLarge(a, x);
	
	System.out.println("The desired sorted number is  "+number);
		
		
		
		

	}

}
