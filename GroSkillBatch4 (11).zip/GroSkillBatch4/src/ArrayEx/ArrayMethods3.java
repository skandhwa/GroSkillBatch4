package ArrayEx;

import java.util.Arrays;

public class ArrayMethods3 {

	public static void main(String[] args) {
		
		int []a= {33,4,12,65,2};
		
		Arrays.sort(a);
		
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		
		

	}

}
