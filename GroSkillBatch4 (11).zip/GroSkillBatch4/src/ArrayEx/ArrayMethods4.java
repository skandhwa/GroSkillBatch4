package ArrayEx;

import java.util.Arrays;

public class ArrayMethods4 {

	public static void main(String[] args) {
		
		char []ch= {'a','x','y','u'};
		
		Arrays.toString(ch);
		
		System.out.println(ch);
		

	}

}
