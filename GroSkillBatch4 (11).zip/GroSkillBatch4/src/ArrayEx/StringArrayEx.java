package ArrayEx;

public class StringArrayEx {

	public static void main(String[] args) {
		
		String []str = {"apple","banana","orange","kiwi"};
		
		int x=str.length;
		
		System.out.println("Length of array is  "+x);
		
		
		for(String s:str)
		{
			System.out.println(s);
		}
		

	}

}
