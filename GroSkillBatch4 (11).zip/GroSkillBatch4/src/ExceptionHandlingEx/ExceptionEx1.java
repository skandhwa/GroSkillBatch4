package ExceptionHandlingEx;

public class ExceptionEx1 {

	public static void main(String[] args) {
		
		try
		{
		
		int a=10;
		int b=a/0;
		System.out.println(b);
		}
		
		catch(Exception a)
		{
			System.out.println("caught with  "+a.getMessage());
		}
		
		
		int x=10;
		int y=20;
		int z=x+y;
		System.out.println(z);
		
		

	}

}
