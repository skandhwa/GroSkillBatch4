package ExceptionHandlingEx;

public class FinallyClauseEx {

	public static void main(String[] args) {
		
		
		try
		{
		int x=9/3;
		System.out.println(x);
		}
		
//		catch(Exception e)
//		{
//			System.out.println("caught with  "+e);
//		}
		
		finally
		{
			int a=30/3;
			System.out.println(a);
		}
		
		int p=20,q=30;
		int r=p+q;
		System.out.println(r);
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
