package ExceptionHandlingEx;

public class NestedTryCatch {

	public static void main(String[] args) {
		
		try
		{
			try
			{
				int x=10/0;
				System.out.println(x);
			}
			catch(Exception e1)
			{
				System.out.println(e1.getMessage());
			}
			
			int p=10,q=20;
			int r=p+q;
			System.out.println(r);
			
			try
			{
				int []y= {10,20,30};
				System.out.println(y[5]);
			}
			catch(Exception e1)
			{
				System.out.println(e1.getMessage());
			}
			
			int p1=10,q1=20;
			int r1=p1*q1;
			System.out.println(r1);
			
			try
			{
				String str=null;
				str=str.concat("hello");
				System.out.println(str);
			}
			catch(Exception e1)
			{
				System.out.println(e1.getMessage());
			}
			
			int p2=10,q2=20;
			int r2=q2/p2;
			System.out.println(r2);
			
			
		}
		
		catch(Exception e)
		{
			System.out.println("Caught  "+e.getMessage());
		}
		
		
		System.out.println("All code executed and working fine");
		
		

	}

}
