package ExceptionHandlingEx;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

class EmployeeAccess
{
	public static void validateAccess(int id) throws FileNotFoundException
	{
		if(id==12345)
		{
			System.out.println("You are elligible to access the file");
			File f=new File("D:\\RandomDataGeneration.txt");
			boolean flag=f.canRead();
			System.out.println("Are you able to read the file  "+flag);
		}
		else
		{
			throw new FileNotFoundException("You dont have access");
		}
	}
}



public class ThrowCompileException {

	public static void main(String[] args) throws IOException {
		
		EmployeeAccess.validateAccess(22345);
		
		
	
		
		
		
		
		
		
		

	}

}
