package PolyMorphismAndKeywords;

class T11
{
	static int id=1234;
	static String name="abcd";
	static float salary=80000f;
	
	static  void change()
	{
		salary=90000f;
	}
	
	
	static void display()
	{
		System.out.println(id+"  "+name+"  "+salary);
	}
	
	void message()
	{
		System.out.println(id+"  "+name+"  "+salary);
	}
	
}



public class staticAndNonStatic {

	public static void main(String[] args) {
		
		T11.change();
		T11.display();
		

	}

}
