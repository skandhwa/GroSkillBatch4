package StringDeclaration;

public class StringBufferInsertEx {

	public static void main(String[] args) {
		
		StringBuffer sb1=new StringBuffer("Hello");
		sb1.insert(1,"Saurabh");
		
		System.out.println(sb1);
		
		

	}

}
