package StringDeclaration;

public class StringBufferReplace {

	public static void main(String[] args) {
		
		StringBuffer sb=new StringBuffer("test");
		
		
		int x=sb.length();
		System.out.println("Length is  "+x);
		
		
		sb.reverse();
		System.out.println(sb);
		
		
		
		sb.replace(2, 5, "test");
		System.out.println(sb);
		
		
		
		

	}

}
