package StringDeclaration;

public class StringMethod5 {

	public static void main(String[] args) {
		
//		String str="sars sam";
//		
//		str=str.replace("sam","mam");
//		
//		System.out.println(str);
		
		
	    String str="hello world";
	    
//	String str1=    str.replaceAll('h','o');
	    
	//    System.out.println(str1);
	    
	    
		
	}

}
