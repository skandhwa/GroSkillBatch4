package ConditionalStatements;

public class FactorialOfNumber {

	public static void main(String[] args) {
		
		int fact=1;
		
		for(int i=5;i>0;i--)///i=5,5>0///i=4,4>0//i=3,3>0//i=2,2>0//i=1,1>0//i=0,0>0
		{
			fact=fact*i;///fact=1*5=5///fact=5*4=20//fact=20*3=60//fact=60*2=120
		}                                                           ///fact=120*1=120
		
		System.out.println(fact);
		

	}

}
