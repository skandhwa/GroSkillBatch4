package FileExample;

import java.io.File;
import java.io.IOException;

public class FileCreation {

	public static void main(String[] args) throws IOException {
		
		File obj=new File("D:\\TestDataFolder17thOct\\MyTest102.txt");
	boolean flag=	obj.createNewFile();
	
	
	
	
	System.out.println("Is the file created  "+flag);
		
	System.out.println(obj.getName());
		
	System.out.println(obj.getAbsolutePath());
	
	boolean flag1=obj.canRead();
	System.out.println("Is the file readable  "+flag1);
	
	boolean flag2=obj.canWrite();
	System.out.println("Is the file Writable  "+flag2);
	
	System.out.println("Length of the file is  "+obj.length());
	
	boolean x=obj.delete();
	System.out.println("Is the file deleted  "+x);
	
	
	 
	
	
	
		
		

	}

}
