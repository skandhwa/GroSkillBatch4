package ListExamples;

import java.util.ArrayList;
import java.util.List;

public class ArrayListEx4 {

	public static void main(String[] args) {
		
		List<String> li=new ArrayList<String>();
		li.add("melon");
		li.add("apple");
		li.add("orange");
		li.add("grapes");
		
		
		List<String> li2=new ArrayList<String>();
		li2.add("kiwi");
		li2.add("guava");
		li2.add("orange");
		li2.add("pines");
		
		
		li.addAll(li2);
		
		System.out.println(li);
		
		
	}

}
