package ListExamples;

import java.util.ArrayList;
import java.util.List;

public class ArrayListEx7 {

	public static void main(String[] args) {
		 
		
		List<String> li=new ArrayList<String>();
		li.add("melon");
		li.add("apple");
		li.add("orange");
		li.add("grapes");
		
		li.remove(2);
		
		System.out.println(li);
		
		li.clear();
		System.out.println("After clearing elements are");
		
		System.out.println(li);
		
		
		
		

	}

}
