package MyPack1;



class C1
{
	int x=10; /// instance variable ///global variable to a class
	
	
	void display()
	{
		int a=30;
		System.out.println("Hello");
	}
	
	void test()
	{
		int y=x+20;
		int b=a+20;
		System.out.println(y);
	}
	
	
	
	
}

public class ClassAndObject {

	public static void main(String[] args) {
		
		C1 obj=new C1();
		obj.display();
		
		
		

	}

}
