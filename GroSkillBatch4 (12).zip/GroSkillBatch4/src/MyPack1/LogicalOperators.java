package MyPack1;

public class LogicalOperators {

	public static void main(String[] args) {
		
		int a=10, b=20, c=40;
		
		if(a>b || c<a  && b<c) // 10<20  && 40>10 && 20<40
		{
			System.out.println("I am true");
		}
		
		else
		{
			System.out.println("I am false");
		}
		
		
		
		

	}

}
