package PolyMorphismAndKeywords;

class A2
{
	public static int sum(int x,int y)
	{
		return x+y;
		
	}
	
	public static float sum(int a,int b,int c)
	{
		return a+b+c;
	}
}



public class MethodOverloadingEx {

	public static void main(String[] args) {
		
		//A2 obj=new A2();
	System.out.println(A2.sum(12, 32));	
	System.out.println	(A2.sum(34,56,77));
		

	}

}
