package PolyMorphismAndKeywords;

class T5
{
	static int id;
	static int calculate(int x,int y)
	{
		
		return x*y;
		
		
	}
}



public class StaticMethodEx2 {

	public static void main(String[] args) {
		
	System.out.println(T5.calculate(34, 10));	
		

	}

}
