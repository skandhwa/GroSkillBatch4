package StringDeclaration;

public class StringMethod3 {

	public static void main(String[] args) {
		
		String str="Republic";
		
//	String str1=	str.substring(0);
//	
//	System.out.println(str1);
		
		String str2=str.substring(3, 7);
		
		System.out.println(str2);
		
		
		
		
		

	}

}
