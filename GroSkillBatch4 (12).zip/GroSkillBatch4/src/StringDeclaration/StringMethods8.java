package StringDeclaration;

public class StringMethods8 {

	public static void main(String[] args) {
		
		String str="InDia";
	String s1=	str.toLowerCase();
	
	System.out.println("String value is  "+s1);
	
	
	String str2= "       Hello      Saurabh       ";
	
	str2=str2.trim();
	System.out.println("Trimmed String is  "+str2);
		
		

	}

}
