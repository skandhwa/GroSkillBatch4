package AbstractionEx;

interface I10
{
	default void test()
	{
		System.out.println("Hello");
	}
}

class C10 implements I10
{
	
}




public class DefaultMethod_Interface {

	public static void main(String[] args) {
		
		I10 ref=new C10();
		ref.test();
		
		
		

	}

}
