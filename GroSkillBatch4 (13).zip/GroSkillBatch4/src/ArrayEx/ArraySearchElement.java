package ArrayEx;

public class ArraySearchElement {

	public static void main(String[] args) {
		
		int []a= {12,56,32,44,99};
		
		int k=32;
		
		for(int i=0;i<a.length;i++)//i=0,0<5
		{
			if(a[i]==k)///a[0]=12,12==32
			{
				System.out.println("element  " +k+ " found at index  " +i+ " position");
			}
		}
		
	}

}
