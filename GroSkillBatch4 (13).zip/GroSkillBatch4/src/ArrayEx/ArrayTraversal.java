package ArrayEx;

public class ArrayTraversal {

	public static void main(String[] args) {
		
		
		int []c= {34,67,88,99,105};
		
		int len=c.length;
		
		///for loop
		
		for(int i=0;i<len;i++)///i=0,0<5//i=1,1<5
		{
			
			System.out.println(c[i]);///c[0] ,,c[1],c[2]
		}
		
		
		System.out.println("Using for each loop");
		////for each loop 
		
		for(int x:c)
		{
			System.out.println(x);
		}
		
		
		
		
		

	}

}
