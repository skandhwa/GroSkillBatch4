package EncapsulationEx;

public class EncapEx2 {

	public static void main(String[] args) {
		
		X8 obj=new X8();
//		obj.setName("saurabh");
//		obj.setId(1234);
//		obj.setAddress("Delhi");
		
		obj.getId();
		obj.getName();
		obj.getAddress();
		
		

	}

}
