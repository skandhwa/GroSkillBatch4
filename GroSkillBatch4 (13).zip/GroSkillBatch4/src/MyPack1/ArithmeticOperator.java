package MyPack1;

public class ArithmeticOperator {

	public static void main(String[] args) {
		
		int a=20;
		int b=30;
		
		
		int c=a/b;
		
		System.out.println(c);
		
		
		int x=93;
		int y=21;
		int z=x/y;
		System.out.println(z);
		

	}

}
