package MyPack1;

class C4
{
	void display()
	{
		System.out.println("Hello");
	}
	
	void test()
	{
		System.out.println("Hi");
	}
	int sum(int x,int y)
	{
		return x+y;
	}
	
	void message()
	{
		display();
		test();
		System.out.println (sum(34,56));
	}
	
	
	
}



public class CascadedMethods {

	public static void main(String[] args) {
		
		C4 obj=new C4();
	obj.message();
		

	}

}
