package MyPack1;


public class MyTest1 {
	
	void method()
	{
		System.out.println("display");
	}
	
	
	

	public static void main(String[] a) {
		
		MyTest1 obj=new MyTest1();
		obj.method();
		
		
		
		
		
		

	}

}
