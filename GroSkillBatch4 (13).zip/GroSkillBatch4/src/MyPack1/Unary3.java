package MyPack1;

public class Unary3 {

	public static void main(String[] args) {
	
		int a=5 ;
		int b=6;
		int c=7;
		
		
	int r= a++ + b-- + c-- - --a + ++b	+ ++c;
	
	
	/// 5 + 6 + 7 - 5 + 6 + 7
	
	///  a=6 , b=5 ,c=6
	
	System.out.println(r);
		
		

	}

}
