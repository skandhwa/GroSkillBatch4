package PolyMorphismAndKeywords;

class T1
{
	int id;
	String name;
	float salary;
	String address;
	
	
	T1(int id,String name,float salary)
	{
		this.id=id;
		this.name=name;
		this.salary=salary;
	}
	
	T1(int id,String name,float salary,String address)
	{
		this(id,name,salary);
		this.address=address;
	}
	void display()
	{
		System.out.println(id+"  "+name+" "+salary+"  "+address );
	}
	}

public class ThisKeywordEx {

	public static void main(String[] args) {
		
		T1 obj=new T1(1234,"Gaurabh",90000f);
		obj.display();
		
		T1 obj1=new T1(4567,"John",87000f,"Delhi");
		obj1.display();
		

	}

}
