package SetInterface;

import java.util.LinkedHashSet;
import java.util.Set;

public class LinkedHashSetEx3 {

	public static void main(String[] args) {
		
		 Set<Integer> s1=new LinkedHashSet<Integer>();
	        
			s1.add(105);
			s1.add(78);
			s1.add(90);
			s1.add(13);
			
			int x=s1.size();
			
			System.out.println("Size of set is  "+x);
			
	boolean flag=    s1.contains(105);		
	
	System.out.println("Does set contains 105  "+flag);
	
	s1.remove(78);
	
	System.out.println(s1);
	
	s1.clear();
	
	System.out.println(s1);
	
	
		

	}

}
