package StringDeclaration;

public class StringEx1 {

	public static void main(String[] args) {
		
		String str="Saurabh";////By using STring literal
		
		///String str1="Saurabh";
		
		str=str.concat("Trainer");
		
		System.out.println(str);
		
		String str2=new String("Saurabh");
		
		
		
		

	}

}
