package StringDeclaration;

public class StringMethod4 {

	public static void main(String[] args) {
		
//		String str="saurabh@trainer@testing";
//		
//	String[]s1=	str.split("@");
//	
//	
//	System.out.println(s1[0]);
//	
//	System.out.println(s1[1]);
//	
	
	String str="#@fest#college%#sonu#&nigam";
	
	String []s1=str.split("#");
	
	for(int i=0;i<s1.length;i++)
	{
		System.out.println(s1[i]);
	}
		
		

	}

}
