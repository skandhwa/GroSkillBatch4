package StringDeclaration;

public class StringMethods10 {

	public static void main(String[] args) {
		
		String str="   Indian Citizen   ";
		
	boolean flag=	str.contains(" ");
	
	System.out.println("Does String Contains Citizen "+flag);
	
	
	str=str.replaceAll(" ","");
	
	System.out.println(str);
		

	}

}
