package StringDeclaration;

public class StringMethods11 {

	public static void main(String[] args) {
		
		String str="Indian";
		
		String str1="indian";
		
	int x=	str1.compareTo(str);
	
	System.out.println(x);
	
	
	
		
		
		
	}

}
