package StringDeclaration;

public class StringMethods6 {

	public static void main(String[] args) {
		
		String str="@#467saurabh)(^#";
         
		str=str.replaceAll("[^a-zA-Z]","");
		
		System.out.println(str);
		
		
		

	}

}
