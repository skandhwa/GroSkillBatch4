package StringDeclaration;

public class StringReverseandPalindrome {

	public static void main(String[] args) {
		
		String str="madam";//
		
		String str1=str;
		
		str=str.toLowerCase();
		
		String revstr="";
		
		for(int i=str.length()-1;i>=0;i--)///i=3,3>=0//i=2,2>=0//i=1,1>=0
		{
			 revstr=revstr+   str.charAt(i);//revstr=""+e=e//revstr=e+l=el//revstr=el+o=elo
		}
		
		System.out.println(revstr);
		
		
		if(str1.equalsIgnoreCase(revstr))
		{
			System.out.println("The String is plaindrome");
		}
		
		else
		{
			System.out.println("The String is not plaindrome");
		}
		
	}

}
