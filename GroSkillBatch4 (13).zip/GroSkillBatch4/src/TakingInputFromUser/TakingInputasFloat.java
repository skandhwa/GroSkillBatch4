package TakingInputFromUser;

import java.util.Scanner;

public class TakingInputasFloat {

	public static void main(String[] args) {
		
		
System.out.println("Enter a number");
		
		Scanner sc=new Scanner(System.in);
		float num=sc.nextFloat();
		
		System.out.println("Enter the second number");
		
		float num1=sc.nextFloat();
		
		float result= num1+num;
		
		System.out.println("The sum is  "+result);

	}

}
