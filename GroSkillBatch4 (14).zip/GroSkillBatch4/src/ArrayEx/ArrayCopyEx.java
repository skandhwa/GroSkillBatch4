package ArrayEx;

public class ArrayCopyEx {

	public static void main(String[] args) {
		
		int []a= {12,56,77,89};
		
		int []b=new int[a.length];
		
		for(int i=0;i<a.length;i++)///i=0,0<4 //i=1,1<4
		{
			b[i]=a[i];///b[0]=a[0]//b[1]=
			
			System.out.println(b[i]);
		}
		
		
		

	}

}
