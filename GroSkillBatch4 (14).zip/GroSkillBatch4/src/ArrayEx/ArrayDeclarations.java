package ArrayEx;

public class ArrayDeclarations {

	public static void main(String[] args) {
		
		int []a= {12,45,78,98};
		
		int []b=new int[] {12,65,77,43,99,105};
		
		int []c=new int[5];
		
		/// Array index out of bounds
		
		
		

	}

}
