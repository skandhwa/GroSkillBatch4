package ArrayEx;

import java.util.Arrays;

public class ArrayMethods2 {

	public static void main(String[] args) {
		
		int []a= {195,187,12,66,55,90,299};
		
		int []b= {195,187,12,66,55,190,99};
		
	int x=	Arrays.compare(b,a);
	System.out.println(x);
		

	}

}
