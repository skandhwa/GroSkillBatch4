package ArrayEx;

public class ArraySortingEx {

	public static void main(String[] args) {
		
		int []a= {19,4,8,1};
		
		for(int i=0;i<a.length;i++)///i=0,0<4//i=1,1<4//i=2,2<4//i=3,3<4//i=4,4<4
		{
			for(int j=i+1;j<a.length;j++)///
			{
				if(a[i]>a[j])// a[2]>a[3]
				{
					int temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
			System.out.println(a[i]);
		}
		
		
		
		
		

	}

}
