package ConditionalStatements;

public class FibbonacciSeries {

	public static void main(String[] args) {
		
		int n1=0,n2=1,n3;
		
		int range=7;
		
		System.out.print(n1+" ");///0
		System.out.print(n2+" ");//1
		
		for(int i=0;i<range;i++)///i=1,1<7//i=2,2<7//i=3,3<7
		{
			n3=n1+n2;//n3=0+1=1//n3=1+1=2//n3=1+2=3 //n3=2+3=5
			System.out.print(n3+" ");////1///2///3///5
			n1=n2;//n1=1//n1=1//n1=2///n1=3
			n2=n3;//n2=1//n2=2//n2=3//n2=5
			
			
		}
		
		
		
		

	}

}
