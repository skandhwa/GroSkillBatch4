package ConditionalStatements;

public class ifStatement {

	public static void main(String[] args) {
		
		int x=10;
		
		if(x>4)
		{
			System.out.println("correct");
		}
		
		

	}

}
