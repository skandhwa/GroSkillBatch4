package ExceptionHandlingEx;

public class ExceptionEx2 {

	public static void main(String[] args) {
		
		try
		{
		int []a= {10,20,30,40};
		System.out.println(a[6]);
		}
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("caught with "+e);
		}
		
		int x=10;
		int y=20;
		int z=x+y;
		System.out.println(z);

	}

}
