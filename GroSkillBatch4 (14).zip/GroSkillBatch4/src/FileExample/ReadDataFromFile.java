package FileExample;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class ReadDataFromFile {

	public static void main(String[] args) throws FileNotFoundException {
		
		File obj=new File("D:/TestDataFolder17thOct/MyTest.txt‪");
		Scanner sc=new Scanner(obj);
		
		
		//FileReader f=new FileReader("");
		
		
		
		while(sc.hasNextLine()==true)
		{
			String fileContent=   sc.nextLine();
			System.out.println(fileContent);
			
		}
		
		sc.close();
		
		////   D:\\TestDataFolder17thOct\\MyTest.txt
		

	}

}
