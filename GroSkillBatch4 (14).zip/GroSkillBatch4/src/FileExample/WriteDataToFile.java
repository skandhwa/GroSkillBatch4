package FileExample;

import java.io.FileWriter;
import java.io.IOException;

public class WriteDataToFile {

	public static void main(String[] args) throws IOException {
		
		FileWriter fw=new FileWriter("D:\\TestDataFolder17thOct\\MyTest.txt");
		fw.write("Python is a robust language\n");
		
		System.out.println("Content added succesfully\n");
		System.out.println();
		
		fw.append("Java is a robust language");
		System.out.println("Content edited succesfully");
		
		
		fw.close();
		
		
		

	}

}
