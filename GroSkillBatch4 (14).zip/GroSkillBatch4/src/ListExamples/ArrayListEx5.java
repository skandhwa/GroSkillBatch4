package ListExamples;

import java.util.ArrayList;
import java.util.List;

public class ArrayListEx5 {

	public static void main(String[] args) {
		
		
		List<String> li=new ArrayList<String>();
		li.add("melon");
		li.add("apple");
		li.add("orange");
		li.add("grapes");
		li.add("strawberry");
		
//	boolean flag=	li.contains("apple");
//
//	System.out.println(flag);
	
	List<String> li2=new ArrayList<String>();
	
	li2.add("melon");
	li2.add("apple");
	li2.add("orange");
	li2.add("grapes");
	li2.add("lemon");
	
	
//	li2.add("kiwi");
//	li2.add("guava");
//	li2.add("orange");
//	li2.add("pines");
	
	
boolean flag2=	li.containsAll(li2);

System.out.println(flag2);


	
	

	
	
	}

}
