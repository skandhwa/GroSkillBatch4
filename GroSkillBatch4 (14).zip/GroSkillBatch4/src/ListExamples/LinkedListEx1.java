package ListExamples;

import java.util.LinkedList;
import java.util.List;

public class LinkedListEx1 {

	public static void main(String[] args) {
		
		List<String> li=new LinkedList<String>();
		li.add("apple");
		li.add("melon");
		li.add("guava");
		li.add("orange");
		
		for(String x:li)
		{
			System.out.println(x);
		}
		
		
		

	}

}
