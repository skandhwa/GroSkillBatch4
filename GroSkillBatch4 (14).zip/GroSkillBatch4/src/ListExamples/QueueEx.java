package ListExamples;

import java.util.PriorityQueue;
import java.util.Queue;

public class QueueEx {

	public static void main(String[] args) {
		
		Queue<Integer> q=new PriorityQueue<Integer>();
		
		q.add(34);
		q.add(105);
		q.add(67);
		q.add(108);
		
		System.out.println(q);
		
		q.remove();
		
		System.out.println(q);
		
		

	}

}
