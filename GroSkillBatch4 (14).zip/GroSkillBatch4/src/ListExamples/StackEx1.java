package ListExamples;

import java.util.Stack;

public class StackEx1 {

	public static void main(String[] args) {
		
		Stack<Integer> stk=new Stack<Integer>();
		stk.push(23);
		stk.push(44);
		stk.push(105);
		stk.push(99);
		
		System.out.println(stk);
		
		stk.pop();
		
		System.out.println(stk);
		
	int x=	stk.peek();
	
	System.out.println(x);
		
		
		

	}

}
