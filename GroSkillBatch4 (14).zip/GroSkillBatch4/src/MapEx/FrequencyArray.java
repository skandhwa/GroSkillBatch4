package MapEx;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyArray {

	public static void main(String[] args) {
		
		int []a= {10,20,20,10,10,30};
		
		Map<Integer,Integer> mp=new LinkedHashMap<Integer,Integer>();
		
		for(int x:a)
		{
			if(mp.containsKey(x))
			{
				mp.put(x,   (mp.get(x)+1));///mp.put(10,2)
			}
			else
			{
				mp.put(x,1);
			}
		}
		
		
		for(Map.Entry y:mp.entrySet())
			
		{
			System.out.print(y.getKey()+" ");
			System.out.println(y.getValue());
		}
		
		

	}

}
