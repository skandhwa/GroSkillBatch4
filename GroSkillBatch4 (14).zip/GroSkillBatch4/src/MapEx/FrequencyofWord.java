package MapEx;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyofWord {

	public static void main(String[] args) {
		
		String str="tip tap toe tip tap";
		
		Map<String,Integer> mp=new LinkedHashMap<String,Integer>();
		
		String []s1= str.split(" ");
		
		for(String x:s1)
		{
			if(mp.containsKey(x))
			{
				mp.put(x, (mp.get(x)+1));
				
			}
			else
			{
				mp.put(x,1);
			}
			
		}
		
for(Map.Entry y:mp.entrySet())
			
		{
			System.out.print(y.getKey()+" ");
			System.out.println(y.getValue());
		}
		
		
		

	}

}
