package MapEx;

import java.util.LinkedHashMap;
import java.util.Map;

public class LinkedHashMapEx {

	public static void main(String[] args) {
		
		Map<Integer,String> mp=new LinkedHashMap<Integer,String>();
		
		mp.put(7,"banana");
		mp.put(11,"orange");
		mp.put(18,"kiwi");
		mp.put(4,"grapes");
		
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+" ");
			System.out.println(x.getValue());
		}
		
		

	}

}
