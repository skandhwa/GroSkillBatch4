package MapEx;

import java.util.LinkedHashMap;
import java.util.Map;

public class MapEx3 {

	public static void main(String[] args) {
		
        Map<Integer,String> mp=new LinkedHashMap<Integer,String>();
		
		mp.put(7,"banana");
		mp.put(11,"orange");
		mp.put(18,"kiwi");
		mp.put(4,"grapes");
		
	    String value=mp.get(7);
	    
	    System.out.println(value);
	    
	boolean flag=    mp.containsKey(98);
	
	System.out.println(flag);
	
	
	
		
		

	}

}
