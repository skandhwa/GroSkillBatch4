package MapEx;

import java.util.LinkedHashMap;
import java.util.Map;

public class MapEx4 {

	public static void main(String[] args) {
		
		 Map<Integer,String> mp=new LinkedHashMap<Integer,String>();
			
			mp.put(7,"banana");
			mp.put(11,"orange");
			mp.put(18,"kiwi");
			mp.put(4,"grapes");
			
			
Map<Integer,String> mp2=new LinkedHashMap<Integer,String>();
			
			mp2.put(7,"melon");
			mp2.put(11,"lemon");
			mp2.put(28,"apple");
			mp2.put(14,"mango");	
			
			
		mp.putAll(mp2);	
		
		System.out.println(mp);
		
	
			
		

	}

}
