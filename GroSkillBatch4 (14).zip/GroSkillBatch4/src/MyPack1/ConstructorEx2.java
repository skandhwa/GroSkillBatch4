package MyPack1;

class C5
{
	C5()
	{
		System.out.println("Hi");
	}
	
	void display()
	{
		System.out.println("Hello");
	}
}

public class ConstructorEx2 {

	public static void main(String[] args) {
		
		C5 obj=new C5();
		obj.display();
		

	}

}
