package MyPack1;

class C15
{
	void A()
	{
		System.out.println("Hi");
	}
}

class C16 extends C15
{
	void B()
	{
		System.out.println("Hello");
	}
}

class C17 extends C16
{
//	C17()
//	{
//		
//	}
	void C()
	{
		System.out.println("Java");
	}
}



public class InheritanceEx2 {

	public static void main(String[] args) {
		
		C17 obj=new C17();
		obj.A();
		obj.B();
		obj.C();
		
		

	}

}
