package MyPack1;

class C6
{
	void display()
	{
		System.out.println("Hello");
	}
	
	void sum(int a,int b)
	{
		int c=a+b;
		System.out.println(c);
	}
	
	int mul(int x,int y)
	{
		return x*y;
	}
	
	int div(int a,int b)
	{
		return a/b;
	}
	
	
	
	
}




public class MethodInJava {

	public static void main(String[] args) {
		
		C6 obj=new C6();
		obj.display();
		
	    obj.sum(10, 20);
	    
	  System.out.println(obj.mul(12, 4));  
	    
		
		

	}

}
