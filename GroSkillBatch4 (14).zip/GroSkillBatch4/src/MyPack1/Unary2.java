package MyPack1;

public class Unary2 {

	public static void main(String[] args) {
		
		int x=10;
		int y=20 ;
		
		
		int z= x++ + ++y + ++x;
		
		//// 10 + 21 + 12
		
		
		////x=11, y=21 , 
		
		System.out.println(z);
		
		

	}

}
