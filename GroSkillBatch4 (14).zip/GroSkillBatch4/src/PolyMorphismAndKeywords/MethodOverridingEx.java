package PolyMorphismAndKeywords;

class RBIBank
{
	 static int getROI(int x,int y)
	{
		return x+y;
	}
}

class SBI extends RBIBank
{
	
	int getROI(int x,int y)
	{
		return x-y;
	}
	
	void display()
	{
		getROI(3,4);
		super.getROI(4, 5);
	}
	
}

public class MethodOverridingEx {

	public static void main(String[] args) {
		
		SBI obj=new SBI();
	System.out.println(obj.getROI(3, 4));
		
		
		RBIBank obj1=new RBIBank();
		System.out.println(obj.getROI(7, 8));
		
		
		
		

	}

}
