package PolyMorphismAndKeywords;

class A1
{
	public int display(int a,int b)
	{
		int c=a+b;
		return c;
	}
	
	public void display(int x,int y)
	{
		int z=x+y;
		System.out.println(z);
	}
}





public class PolyMorphismEx {

	public static void main(String[] args) {
		

	}

}
