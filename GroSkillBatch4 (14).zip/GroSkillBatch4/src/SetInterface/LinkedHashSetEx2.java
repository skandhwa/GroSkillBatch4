package SetInterface;

import java.util.LinkedHashSet;
import java.util.Set;

public class LinkedHashSetEx2 {

	public static void main(String[] args) {
		
		  Set<Integer> s1=new LinkedHashSet<Integer>();
	        
			s1.add(105);
			s1.add(78);
			s1.add(90);
			s1.add(13);
		
			
			
			  Set<Integer> s2=new LinkedHashSet<Integer>();
		        
				s2.add(115);
				s2.add(178);
				s2.add(90);
				s2.add(13);
				
				
	      s1.addAll(s2);
	      
	      System.out.println(s1);
			
		

	}

}
