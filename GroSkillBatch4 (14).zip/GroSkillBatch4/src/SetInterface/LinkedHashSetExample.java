package SetInterface;

import java.util.LinkedHashSet;
import java.util.Set;

public class LinkedHashSetExample {

	public static void main(String[] args) {
		
		
        Set<Integer> s1=new LinkedHashSet<Integer>();
        
		s1.add(105);
		s1.add(78);
		s1.add(90);
		s1.add(13);
		s1.add(90);
		
		System.out.println(s1);
   
	}

}
