package SetInterface;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetEx1 {

	public static void main(String[] args) {
		
		TreeSet<String> s1=new TreeSet<String>();
		s1.add("orange");
		s1.add("apple");
		s1.add("kiwi");
		s1.add("banana");
		s1.add("lemon");
		
		for(String x:s1)
		{
			System.out.println(x);
		}
		
		
		System.out.println();
		System.out.println();
		
		Iterator itr=s1.descendingIterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
	

	}

}
