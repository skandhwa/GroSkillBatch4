package SetInterface;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class TreeSetEx3 {

	public static void main(String[] args) {
		
		
		TreeSet<Integer> s1=new TreeSet<Integer>();
	        
			s1.add(105);
			s1.add(78);
			s1.add(90);
			s1.add(13);
			
		int x=	s1.ceiling(85);
		
		System.out.println(x);
		
	int y=	s1.floor(20);
	System.out.println(y);
		

	}

}
