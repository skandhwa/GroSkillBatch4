package StringDeclaration;

public class StringBuilderEx {

	public static void main(String[] args) {
		
		
	int []a=new int[-5];
	a[0]=12;
	
	System.out.println(a[0]);
	

	}

}
