package StringDeclaration;


class X1
{
	int a;
	X1(int a)
	{
		a=a;
	}
}

void display()
{
	System.out.println(a);
}
public class StringMethod5 {

	public static void main(String[] args) {
		
		X1 obj=new X1(10);
		obj.display();
	}
		
		
		

	    
		
	}
}

