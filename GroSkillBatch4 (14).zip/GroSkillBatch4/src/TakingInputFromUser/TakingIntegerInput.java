package TakingInputFromUser;

import java.util.Scanner;

public class TakingIntegerInput {

	public static void main(String[] args) {
		
		System.out.println("Enter a number");
		
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		
		System.out.println("Enter the second number");
		
		int num1=sc.nextInt();
		
		int result= num1+num;
		
		System.out.println("The sum is  "+result);
		
		
		
		
		
		
		
		

	}

}
