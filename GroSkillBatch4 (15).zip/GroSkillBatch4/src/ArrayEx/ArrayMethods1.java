package ArrayEx;

import java.util.Arrays;

public class ArrayMethods1 {

	public static void main(String[] args) {
		
		
		int []a= {45,87,12,66,55};
		
		int []b= {45,87,12,66,55};
		
	boolean flag=	Arrays.equals(a,b);
	
	System.out.println("Are both arrays equal "+flag);
	
	
	
	
	
		

	}

}
