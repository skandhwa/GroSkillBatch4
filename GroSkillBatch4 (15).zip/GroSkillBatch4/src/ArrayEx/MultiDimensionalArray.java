package ArrayEx;

public class MultiDimensionalArray {

	public static void main(String[] args) {
		
		int [][]a=new int [][] { {1,4,5} ,{2,9,6}, {3,8,7}  };
		
		for(int i=0;i<a.length;i++)///i=0,0<3
		{
			for(int j=0;j<a.length;j++)//j=0,0<3//j=1,1<3 //j=2,2<3//j=3,3<3
			{
				System.out.print(a[i][j]+"  ");///a[0][0]//a[0][1]//a[0][2]
				
			}
			
			System.out.println();
		}
		
		
		

	}

}
