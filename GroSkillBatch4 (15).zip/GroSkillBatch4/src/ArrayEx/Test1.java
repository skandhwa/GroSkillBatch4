package ArrayEx;

public class Test1 {

	public static void main(String[] args) {
		
		
		String s1 = "Hello";  
		String s2 = "Hello";  
		System.out.println(s1 == s2);  


	}

}
