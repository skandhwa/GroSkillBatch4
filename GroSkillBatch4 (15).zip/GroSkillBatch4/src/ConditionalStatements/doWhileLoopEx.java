package ConditionalStatements;

public class doWhileLoopEx {

	public static void main(String[] args) {
		
		int i=1;
		
		do
		{
			System.out.println(i); //1//2//3//4
			i++;
		}
		
		while(i<5); 
		
		
		
		

	}

}
