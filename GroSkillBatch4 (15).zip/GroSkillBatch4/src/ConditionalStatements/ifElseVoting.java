package ConditionalStatements;

public class ifElseVoting {

	public static void main(String[] args) {
		
		int age=13;
		
		
		if(age>18)
		{
			System.out.println("You are elligible to vote");
			
			if(age>75)
			{
				System.out.println("No need to come to polling booth , will take vote from home or online");
				
				if(age>85)
				{
					System.out.println("You can do online voting");
				}
				
				
				
			}
			
			
			
		}
		
		else if(age<18)
		{
			System.out.println("You are not elligible");
		}
		
		
		

	}

}
