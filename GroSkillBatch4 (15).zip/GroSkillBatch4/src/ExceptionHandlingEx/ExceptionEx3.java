package ExceptionHandlingEx;

public class ExceptionEx3 {

	public static void main(String[] args) {
		
		try
		{
		String str=null;
		
		int a=str.length();
		System.out.println("Length of String  "+a);
		}
		catch(NullPointerException e)
		{
			System.out.println("caught with  "+e.getMessage());
		}
		
		
		
		int x=10;
		int y=20;
		int z=x+y;
		System.out.println(z);


	}

}
