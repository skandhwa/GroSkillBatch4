package ExceptionHandlingEx;

public class MultiTryCatch {

	public static void main(String[] args) {
		
		try
		{
			
			int []a= {2,3,4};
			System.out.println(a[5]);
			
			
		int x=20/0;
		System.out.println(x);
		
		
		
		
		
		String str=null;
		str=str.concat("hello");
		System.out.println(str);
		}
		
		catch(ArrayIndexOutOfBoundsException e1)
		{
			System.out.println("caught with"  +e1.getMessage());
		}
		
		catch(ArithmeticException e2)
		{
			System.out.println("caught with"  +e2.getMessage());
		}
		
		catch(NullPointerException e3)
		{
			System.out.println("caught with"  +e3.getMessage());
		}
		
		
		int p=20;
		int q=10;
		int r=p+q;
		System.out.println(r);
		
		
		
		

	}

}
