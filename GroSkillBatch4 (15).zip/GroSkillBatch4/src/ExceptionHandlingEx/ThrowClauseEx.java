package ExceptionHandlingEx;

class Election
{
	public static void validateAge(int a)
	{
		if(a<18)
		{
			throw new ArithmeticException("Invalid age");
		}
		
		else
		{
			System.out.println("You are elligible to vote");
		}
		
		
		int current_vote=23000;
		System.out.println("Before cast current vote is  "+current_vote);
		System.out.println("After you cast current vote is  "+current_vote+1);
		
		
	}
}



public class ThrowClauseEx {

	public static void main(String[] args) {
		
		Election.validateAge(14);
		
		
		

	}

}
