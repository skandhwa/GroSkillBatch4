package ExceptionHandlingEx;

public class ThrowsClauseEx {

	public static void main(String[] args) throws InterruptedException {
		
		int x=20;
		int y=10;
		int z=x+y;
		System.out.println(z);
		
		Thread.sleep(3000);
		

	}

}
