package JavaProgramsEx;

public class AddingElementsOddPosition {

	public static void main(String[] args) {
		
		int []a= {1,4,7,3,8,6};
		int sum=0;
		
		for(int i=1;i<a.length;i=i+2)
		{
			sum=sum+a[i];
		}
		
		System.out.println("Sum is  "+sum);
		
		
		
		

	}

}
