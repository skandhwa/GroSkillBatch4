package JavaProgramsEx;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GroupingElements {

	public static void main(String[] args) {
		
		int []a= {-1,3,0,1,0,2,0};
		
		List<Integer> li=new ArrayList<Integer>();
		List<Integer> li2=new ArrayList<Integer>();
		
		for(Integer x:a)
		{
			if(x!=0)
			{
				li.add(x);
				Collections.sort(li);
				Collections.reverse(li);
			}
			else
			{
				li2.add(x);
			}
		}
		
		
		li.addAll(li2);
		
		for(Integer y:li)
		{
			System.out.print(y+"  ");
		}
		
		
		
		
	}

}
