package JavaProgramsEx;

public class RemoveSpecialCharacters {

	public static void main(String[] args) {
		
		String str= "A$%^&1234bnjk678$#";
		
		str=str.replaceAll("[^a-z]","");
		
		System.out.println(str);
		

	}

}
