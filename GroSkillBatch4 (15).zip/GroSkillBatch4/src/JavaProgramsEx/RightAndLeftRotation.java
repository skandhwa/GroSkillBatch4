package JavaProgramsEx;

public class RightAndLeftRotation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
