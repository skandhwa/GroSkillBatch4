package JavaProgramsEx;

public class SortWithLength {

	public static void main(String[] args) {
		
		String str="java is a programming language";
		
		String []a= str.split(" ");
		
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i].length()>a[j].length())
				{
					String temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		
		for(int i=0;i<a.length;i++)
		{
			System.out.print(a[i]+" ");
		}
		
		
		

	}

}
