package JavaProgramsEx;

public class UsingCharacterCLass {

	public static void main(String[] args) {
		
		String str="S@12*(abO678";
		int sum=0;
		
		char []ch=str.toCharArray();
		
		for(int i=0;i<ch.length;i++)
		{
			if(Character.isDigit(ch[i]))
			{
				sum=sum+Character.getNumericValue(ch[i]);
			}
		}
		
		System.out.println(sum);
		
		
		
	}

}
