package ListExamples;

import java.util.ArrayList;
import java.util.List;

public class ArrayListEx3 {

	public static void main(String[] args) {
		
		List<String> li=new ArrayList<String>();
		li.add("melon");
		li.add("apple");
		li.add("orange");
		li.add("grapes");
		
		System.out.println(li);
		
		li.set(2,"guava");
		
		li.add(8, "kiwi");
		System.out.println(li);
		
		System.out.println("After adding another element");
		System.out.println(li);
		
	System.out.println(li.get(3));	
	
	li.add(2,"banana");
	System.out.println("Adding banana");
	
	System.out.println(li);
		
		

	}

}
