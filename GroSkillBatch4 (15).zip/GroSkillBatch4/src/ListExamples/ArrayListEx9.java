package ListExamples;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ArrayListEx9 {

	public static void main(String[] args) {
		
		int []a= {12,34,56,88};
		
		List<Integer> li=new ArrayList<Integer>();
		
		for(int x:a)
		{
			li.add(x);
		}
		
		 System.out.println(li);
		 
		 
	       
		

	}

}
