package MapEx;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyofString {

	public static void main(String[] args) {
		
		String str="tests";
		
		Map<Character,Integer> mp=new LinkedHashMap<Character,Integer>();
		
		char []s1=str.toCharArray();
		
		for(char x:s1)
		{
			if(mp.containsKey(x))
			{
				mp.put(x, (mp.get(x)+1));
			}
			else
			{
				mp.put(x,1);
			}
		}
		
for(Map.Entry y:mp.entrySet())
			
		{
			System.out.print(y.getKey()+" ");
			System.out.println(y.getValue());
		}
		
		
		
		
		
		

	}

}
