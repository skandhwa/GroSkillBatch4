package MapEx;

import java.util.HashMap;
import java.util.Map;

public class MapExample1 {

	public static void main(String[] args) {
		
		Map<Integer,String> mp=new HashMap<Integer,String>();
		
		mp.put(12,"banana");
		mp.put(34,"orange");
		mp.put(89,"kiwi");
		mp.put(21,"grapes");
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+" ");
			System.out.println(x.getValue());
		}
		
		
		

	}

}
