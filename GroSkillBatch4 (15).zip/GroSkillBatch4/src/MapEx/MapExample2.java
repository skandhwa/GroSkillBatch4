package MapEx;

import java.util.HashMap;
import java.util.Map;

public class MapExample2 {

	public static void main(String[] args) {
		
		
Map<Character,String> mp=new HashMap<Character,String>();
		
		mp.put('D',"banana");
		mp.put('1',"orange");
		mp.put('X',"kiwi");
		mp.put('k',"grapes");
		mp.put(null,null);
		mp.put('u',null);
		mp.put(null,"dragonfruit");
		mp.put(null,"melon");
		
		System.out.println(mp);

	System.out.println(mp.get('X'));	
	
	boolean flag=mp.containsKey('k');
	System.out.println(flag);
	
	
	
		
	}

}
