package MapEx;

import java.util.TreeMap;

public class TreeMapEx {

	public static void main(String[] args) {
	
		TreeMap<Integer,String> mp=new TreeMap<Integer,String>();
		
		mp.put(34, "apple");
		mp.put(45, "banana");
		mp.put(15, "orange");
		mp.put(5, "melon");
		
		System.out.println(mp.descendingMap());
		
		
		
		

	}

}
