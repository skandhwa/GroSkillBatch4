package MyPack1;

public class TernaryOperator {

	public static void main(String[] args) {
		
//		int a=20,b=30;
//		
//		int max= (a>b) ? a:b;
//		
//		System.out.println(max);
		
		
		int a=10, b=20, c=40;
		
		int max = a>b ? (a>c ?a:c) :(b>c?b:c);
		
		System.out.println("Maximum value is  "+max);

	}

}
