package MyPack1;

public class Unary3Ex {

	public static void main(String[] args) {
	
		int p=8;
		int q=6;
		
		int r=3; 
		
		
		int res= p-- - q-- * ++r - ++p -  ++q + ++r;
		
		/// 8 - 6 * 4 - 8 - 6 + 5
		
		//p=7,q=5,r=4
		
		System.out.println(res);
		

	}

}
