package PolyMorphismAndKeywords;

class X2
{
	 static  int sum(int x,int y)
	{
		return x+y;
	}
}

class X3 extends X2
{
	 static int sum(int x,int y)
	{
		return x+y;
	}
}



public class OverridingStaticMethod {

	public static void main(String[] args) {
		
		
		X3.sum(3, 5);
		
		
		

	}

}
