package SetInterface;

import java.util.LinkedHashSet;
import java.util.Set;

public class LinkedHashSetEx4 {

	public static void main(String[] args) {
	
		 Set<Integer> s1=new LinkedHashSet<Integer>();
	        
			s1.add(105);
			s1.add(78);
			s1.add(90);
			s1.add(13);
		
			
			
			  Set<Integer> s2=new LinkedHashSet<Integer>();
		        
				s2.add(115);
				s2.add(178);
				s2.add(90);
				s2.add(13);
				
				
		boolean flag=		s1.containsAll(s2);
		
		System.out.println(flag);
		
		
		s1.retainAll(s2);
		
		System.out.println(s1);
				
				
		

	}

}
