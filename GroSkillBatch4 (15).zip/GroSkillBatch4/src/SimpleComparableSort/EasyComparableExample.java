package SimpleComparableSort;
import java.util.*;


class Fruit implements Comparable<Fruit> 
{
    String name;
    int price;

    Fruit(String name, int price) 
    {
        this.name = name;
        this.price = price;
    }

   
//    public int compareTo(Fruit x) 
//    {
//        return this.price - x.price; 
//    }
    
    
    public int compareTo(Fruit y)
    {
    	return this.name.compareTo(y.name);
    }
}


public class EasyComparableExample {
    public static void main(String[] args) {

        ArrayList<Fruit> fruits = new ArrayList<>();
        fruits.add(new Fruit("Kiwi", 120));
        fruits.add(new Fruit("Banana", 40));
        fruits.add(new Fruit("Apple", 80));

       
        Collections.sort(fruits);

       
        for (Fruit f : fruits) 
        {
            System.out.println(f.name + " - ₹" + f.price);
        }
    }
}
