package StringDeclaration;

public class StringBufferEx {

	public static void main(String[] args) {
		
		StringBuffer sb=new StringBuffer("Saurabh");
		sb.append("trainer");
		System.out.println(sb);
		
		
		StringBuffer sb1=new StringBuffer(10);
		sb1.append("Sa");
		System.out.println(sb1);
		
		
		
	}

}
