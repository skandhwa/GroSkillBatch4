package StringDeclaration;


interface X8
{
	static void display()
	{
		System.out.println("Hello");
	}
	
	void A();
	void B();
	
}

class Y5 implements X8
{

	
	public void A() {
		// TODO Auto-generated method stub
		
	}

	
	public void B() {
		// TODO Auto-generated method stub
		
	}
	
}











public class StringBufferReplace {

	public static void main(String[] args) {
		
		X8 obj=new Y5();
		
		X8.display();
		
	

	}

}
