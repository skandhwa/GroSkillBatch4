package StringDeclaration;

public class StringMethod1 {

	public static void main(String[] args) {
		
		String str="India";
		
      char[]ch= str.toCharArray(); 
      
      for(int i=0;i<ch.length;i++)
      {
    	  System.out.println(ch[i]);
      }
      
	}

}
