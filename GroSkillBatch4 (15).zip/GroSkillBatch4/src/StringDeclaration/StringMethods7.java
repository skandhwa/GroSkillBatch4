package StringDeclaration;

public class StringMethods7 {

	public static void main(String[] args) {
		
		String str="Indian Republican";
		
	int x=	str.indexOf('c',-1);
	
	System.out.println("Index of n is "+x);
		
		

	}

}
