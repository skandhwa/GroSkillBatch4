package StringDeclaration;

public class StringValueOf {

	public static void main(String[] args) {
		
		char ch='A';
		int x=10;
		String p=String.valueOf(x);
		
		
		
		System.out.println(String.valueOf(x));
		
		Integer a=10;
		
		String str=a.toString();
		
		
		
		

	}

}
