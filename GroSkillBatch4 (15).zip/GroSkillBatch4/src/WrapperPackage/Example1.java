package WrapperPackage;

import java.util.ArrayList;
import java.util.List;

public class Example1 {

	public static void main(String[] args) {
		
		
		    int a = 5;    
		    // primitive
	        Integer obj = Integer.valueOf(a);
	        
	        float x=87.5f;
	        
	        Float obj1=Float.valueOf(x);
	        
	        float y=obj1.floatValue();
	        
	        
	        // Boxing (primitive → object)
	        int b = obj.intValue();          // Unboxing (object → primitive)
	        
	        System.out.println("Primitive: " + a);
	        System.out.println("Boxed (Integer Object): " + obj);
	        System.out.println("Unboxed (int): " + b);
	        
	        
	        List<Integer> li=new ArrayList<Integer>();
	        
	        
	        
	        
	}

}
