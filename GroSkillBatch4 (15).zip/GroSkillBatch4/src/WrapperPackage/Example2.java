package WrapperPackage;

public class Example2 {

	public static void main(String[] args) {
		
		int x = 10;
        Integer y = x;    // Autoboxing: int → Integer
        int z = y;       // Auto-unboxing: Integer → int
        
        System.out.println("x: " + x);
        System.out.println("y: " + y);
        System.out.println("z: " + z);
		

	}

}
