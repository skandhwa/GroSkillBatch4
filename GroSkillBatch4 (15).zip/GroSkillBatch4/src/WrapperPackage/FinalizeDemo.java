package WrapperPackage;

public class FinalizeDemo {

   
    protected void finalize() 
    {
        System.out.println("Finalize method is called before object is deleted");
    }

    public static void main(String[] args) {
        FinalizeDemo obj = new FinalizeDemo();

        // Make object eligible for garbage collection
        obj = null;

        // Request JVM to run Garbage Collector
        System.gc();

        System.out.println("Main method finished");
    }
}
