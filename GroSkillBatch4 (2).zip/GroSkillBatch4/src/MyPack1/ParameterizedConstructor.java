package MyPack1;

class C10
{
	int id;
	String name;
	float salary;
	int pincode;
	
	C10(int i,String n,float s)
	{
		id=i;
		name=n;
		salary=s;
	}
	
	C10(int i,String n,float s,int p)
	{
		id=i;
		name=n;
		salary=s;
		pincode=p;
	}
	
	void display()
	{
		System.out.println(id+"  "+name+"  "+salary+"  "+pincode);
	}
	
	
	
}
public class ParameterizedConstructor {

	public static void main(String[] args) {
		
		C10 obj=new C10(1234,"Saurabh",70000f);
		obj.display();
		
		C10 obj1=new C10(3456,"Gaurav",90000f,700034);
		obj1.display();
		
		
		

	}

}
