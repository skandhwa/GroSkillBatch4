package MyPack1;

public class AssignmentOperator {

	public static void main(String[] args) {
		
		
		int x=40;
		
		x%=3; /// x=x*5
		
		System.out.println(x);///shorthand operator
		

	}

}
