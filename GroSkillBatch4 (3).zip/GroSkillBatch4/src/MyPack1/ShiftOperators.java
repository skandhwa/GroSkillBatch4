package MyPack1;

public class ShiftOperators {

	public static void main(String[] args) {
		
		int x=90;
		
		System.out.println(x>>2); /// 90/2pow2= 90/4=
		

	}

}
