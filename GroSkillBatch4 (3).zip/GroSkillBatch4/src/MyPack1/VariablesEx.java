package MyPack1;





public class VariablesEx {

	public static void main(String[] args) {
		
		
		

	}

}
