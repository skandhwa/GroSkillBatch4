package PolyMorphismAndKeywords;

class T12
{
	static void display(int x,int y)
	{
		System.out.println("Hello");
	}
}

class T13 extends T12
{
	static void display(int x,int y)
	{
		System.out.println("Hello");
	}
}



public class OverridingStaticEx {

	public static void main(String[] args) {
		
		
		
		

	}

}
