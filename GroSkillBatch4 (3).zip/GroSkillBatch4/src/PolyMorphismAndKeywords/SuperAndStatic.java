package PolyMorphismAndKeywords;

class T3
{
	int id;
	String name;
	static String add="Delhi";
}

class T4 extends T3
{
	String add="Kolkata";
	 void display()
	{
		System.out.println(add);
		System.out.println(super.add);
	}
}



public class SuperAndStatic {

	public static void main(String[] args) {
		
		T4 obj=new T4();
		obj.display();

	}

}
