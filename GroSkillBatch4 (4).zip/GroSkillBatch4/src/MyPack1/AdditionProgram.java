package MyPack1;

public class AdditionProgram {

	public static void main(String[] args) {
		
		int a=20;
		int b=40;
		
		int c=a+b;
		
		int d=b-a;
		
		System.out.println(c+" ");
		System.out.println(d);
		
		

	}

}
