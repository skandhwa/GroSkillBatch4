package MyPack1;

public class UnaryOperator {

	public static void main(String[] args) {
		
		int x=10;
		
		int y= ++x;///postfix increment
		
		System.out.println(y);
		
		
//		int z= --x; ///prefix decremtn
//		
//		int q= ++x; // prefix increment 
//		
		

	}

}
