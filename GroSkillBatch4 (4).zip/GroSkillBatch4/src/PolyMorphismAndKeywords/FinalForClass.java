package PolyMorphismAndKeywords;

final class M2
{
	void display()
	{
		System.out.println("Hello");
	}
}

class M3 extends M2
{
	void test()
	{
		System.out.println("Hi");
	}
}



public class FinalForClass {

	public static void main(String[] args) {
		
		M3 obj=new M3();
		obj.test();
		obj.display();
		
		
		

	}

}
