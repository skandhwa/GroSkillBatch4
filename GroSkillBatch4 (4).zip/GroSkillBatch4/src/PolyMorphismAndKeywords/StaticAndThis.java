package PolyMorphismAndKeywords;

class T10
{
	int id;
	static String name="IIT";
	float salary;
	
	T10(int id,float salary)
	{
		this.id=id;
		
		this.salary=salary;
	}
	
	static void display()
	{
		System.out.println(id+"  "+name+"  "+salary);
	}
	
}


public class StaticAndThis {

	public static void main(String[] args) {
		
		
		

	}

}
