package ConditionalStatements;

public class WhileLoopEx {

	public static void main(String[] args) {
		
		int i=12;
		
		while(i<=5) //2<5 //3<5 //4<5 ///5<5
		{
			System.out.println(i); ///2///3 //4
			i++;  //2++//3++ //4++
		}
		
		

	}

}
