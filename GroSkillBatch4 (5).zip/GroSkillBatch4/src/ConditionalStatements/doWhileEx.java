package ConditionalStatements;

public class doWhileEx {

	public static void main(String[] args) {
		
		
		int num=25,digit;
		
		int rev=0;
		
		do
		{
			digit=num%10;
			rev=rev*10+digit;
			
			num=num/10;
			
			
		}
		
		while(num>0);
		{
			
			System.out.println("Reverse of number is  "+rev);
			
			
		}
		
		

	}

}
