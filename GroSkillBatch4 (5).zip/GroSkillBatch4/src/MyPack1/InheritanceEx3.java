package MyPack1;

class C18
{
	void A()
	{
		System.out.println("Hi");
	}
}

class C19 extends C18
{
	void B()
	{
		System.out.println("Hello");
	}
}

class C20 extends C18
{
//	C17()
//	{
//		
//	}
	void C()
	{
		System.out.println("Java");
	}
}



public class InheritanceEx3 {

	public static void main(String[] args) {
		
		C20 obj=new C20();
		obj.A();
		//obj.B();
		obj.C();
		
		

	}

}
