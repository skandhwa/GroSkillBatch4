package MyPack1;

public class RelationalOperator {

	public static void main(String[] args) {
		
		//System.out.println(5>=10/2);
		
		int x=10;
		
		int y=20/2;
		
		System.out.println(x!=y);
		
		/// = , ==
		
		
		
	}

}
