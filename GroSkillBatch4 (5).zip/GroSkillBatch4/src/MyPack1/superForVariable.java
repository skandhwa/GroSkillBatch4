package MyPack1;

class D0
{
	String colour="yellow";
}


class D1 extends D0
{
	String colour="red";
}

class D2 extends D0
{
	String colour="black";
	
	void display()
	{
		System.out.println(colour);
		System.out.println(super.colour);
	}
	
}



public class superForVariable {

	public static void main(String[] args) {
		
		D2 obj=new D2();
		obj.display();
		

	}

}
