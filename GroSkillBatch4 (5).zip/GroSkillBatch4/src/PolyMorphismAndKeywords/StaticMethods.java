package PolyMorphismAndKeywords;

class T6
{
	static void display()
	{
		System.out.println("Hello");
	}
}


public class StaticMethods {

	public static void main(String[] args) {
		
		T6.display();
		

	}

}
