package AbstractionEx;

abstract class X6
{
	 abstract  void display();
}


public class AbstractClassEx2 {

	public static void main(String[] args) {
		
		
		

	}

}
