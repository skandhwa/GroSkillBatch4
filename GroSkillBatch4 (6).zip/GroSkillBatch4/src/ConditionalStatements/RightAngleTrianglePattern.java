package ConditionalStatements;

public class RightAngleTrianglePattern {

	public static void main(String[] args) {
		
		int count=0;
		for(int i=1;i<=5;i++)//i=1,1<=5//i=2,2<=5//i=3,3<=5
		{
			for(int j=1;j<=i;j++)///j=1,1<=3
			{
				count++;
				System.out.print(count);///*///* 
			}
			
			System.out.println();
		}
		
		

	}

}
