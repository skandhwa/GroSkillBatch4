package ConditionalStatements;

public class WhileLoopEx {

	public static void main(String[] args) {
		
		int i=12;///initialization
		
		while(i<=5) //condition checking
		{
			System.out.println(i); ///2///3 //4
			i++;  //increment/dectrement
		}
		
		

	}

}
