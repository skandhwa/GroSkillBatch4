package ConditionalStatements;

public class ifElseStatement {

	public static void main(String[] args) {
		
		int a=20;
		
		if(a>50)
		{
			System.out.println("correct");
		}
		else
		{
			System.out.println("In correct");
		}
		
		

	}

}
