package PolyMorphismAndKeywords;


public class MainMethodOverloaded {
	
	public static void main(String s)
	{
		int x= s.length();
		System.out.println(x);
	}

	public static void main(String[] s) {
		
		System.out.println("Hello");
		MainMethodOverloaded.main("India");

	}

}
