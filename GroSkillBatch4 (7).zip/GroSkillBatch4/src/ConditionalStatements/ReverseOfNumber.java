package ConditionalStatements;

public class ReverseOfNumber {

	public static void main(String[] args) {
		
		int num=121, rev=0;
		
		int r=num;
		
		while(num!=0)///123!=0 ///12!=0 //1!=0 //0!=0
		{
			int digit= num%10;///digit=123%10=3 //digit=12%10=2 ///digit=1%10=1
			rev=rev*10+digit;//rev=0*10+3=3 //rev= 3*10+2=32 //rev=32*10+1=321
			num=num/10; /// num=123/10=12 ///num= 12/10=1//num=1/10=0
			
			
		}
		
		System.out.println("Reverse of number is  "+rev);
		
		if(r==rev)
		{
			System.out.println("Palindrome number");
		}
		else
		{
			System.out.println("Not a Palindrome");
		}
		
		
	}

}
