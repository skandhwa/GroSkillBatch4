package GoToStatements;

public class breakEx {

	public static void main(String[] args) {
		
		for(int i=0;i<5;i++)//i=0,0<5//i=1,1<5
		{
			if(i==3)
			{
				break;
			}
			
			System.out.println(i);//0//1//2
		}
		
		
		for(int i=0;i<5;i++)//i=0,0<5//i=1,1<5
		{
			if(i==3)
			{
				continue;
			}
			
			System.out.println(i);//0//1//2
		}
		
		
		

	}

}
