package MyPack1;

public class LogicalNotOperator {

	public static void main(String[] args) {
		
		
		
		

	}

}
