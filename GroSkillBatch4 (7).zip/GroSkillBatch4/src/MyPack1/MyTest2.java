package MyPack1;

public class MyTest2 {

	public static void main(String[] args) {
		
         byte a=-123;  /// -128 to +127
         
         
         short b=12345;
         
         int p=213213213;
         
         float q=2443342678778877887774454.888767565566687f;
         
         double g=213213466734673632432463246327.236543256673243526456325632;
         
         long r=213213293218887L;
         
         char ch='A';
         
         
         char ch1='B';
         
         
		
		

	}

}
