package PolyMorphismAndKeywords;

class C10
{
	static int getSum(int x,int y)
	{
		return x+y;
	}
}

class C11 extends C10
{
	int getSum(int x,int y)
	{
		return x+y;
	}
}




public class finalForMethod {

	public static void main(String[] args) {
		
		
		

	}

}
