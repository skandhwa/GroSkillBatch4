package GoToStatements;

public class SwitchMarks {

	public static void main(String[] args) {
		
		
		int marks=80;
		
		switch(marks)
		{
		case 'A':
			
			if(marks>70 && marks<80)
			{
				System.out.println("excellent");
			}
			break;
			
case 'B':
			
			if(marks>60 && marks<=80)
			{
				System.out.println("very good");
			}
			break;
		
		
		}
		
		
		
		

	}

}
