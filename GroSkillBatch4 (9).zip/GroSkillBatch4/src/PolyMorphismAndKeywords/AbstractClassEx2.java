package PolyMorphismAndKeywords;

abstract class X4
{
	abstract void display();
	abstract void test();
	
	void message()
	{
		System.out.println("Hi");
	}
	
	void demo()
	{
		System.out.println("Hello");
	}
	
}

class X5 extends X4
{
	void display()
	{
		System.out.println("Hi");
	}
	
	void test()
	{
		System.out.println("Hello");
	}
}




public class AbstractClassEx2 {

	public static void main(String[] args) {
		
		X5 obj=new X5();
		obj.test();
		obj.display();
		obj.message();
		obj.demo();
		
		

	}

}
