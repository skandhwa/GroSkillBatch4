package PolyMorphismAndKeywords;

class B5
{
	static final int speed=20;
	 
	static void run()
	{
		speed=40;
		System.out.println(speed);
	}
	
}



public class finalVariableex {

	public static void main(String[] args) {
		
		B5 obj=new B5();
		obj.run();
		

	}

}
