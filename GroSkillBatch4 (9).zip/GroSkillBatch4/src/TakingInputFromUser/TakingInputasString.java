package TakingInputFromUser;

import java.util.Scanner;

public class TakingInputasString {

	public static void main(String[] args) {
		
		System.out.println("Enter a String");
		
		Scanner sc=new Scanner(System.in);
		
		String str=sc.nextLine();
		
		int len =str.length();
		
		System.out.println("Length of String is  "+len);
		
		

	}

}
