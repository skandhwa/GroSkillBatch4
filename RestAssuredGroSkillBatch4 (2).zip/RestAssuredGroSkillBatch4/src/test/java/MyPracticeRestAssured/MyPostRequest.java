package MyPracticeRestAssured;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.notNullValue;

import PayloadData.MyPayload;

public class MyPostRequest {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://reqres.in";
		
	String Response=	given().log().all().headers("content-type","application/json")
		.headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")	
		.body(MyPayload.getPayloadData("Tom","ITA"))
		
		.when().post("api/users")
		.then().log().all().
		assertThat().statusCode(201)
		.extract().response().asString();
	
	System.out.println(Response);
		
		

	}

}
