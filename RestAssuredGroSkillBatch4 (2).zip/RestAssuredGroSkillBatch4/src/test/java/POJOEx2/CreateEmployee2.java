package POJOEx2;

import static io.restassured.RestAssured.given;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import PayloadData.MyPayload;
import io.restassured.RestAssured;

public class CreateEmployee2 {

	public static void main(String[] args) throws JsonProcessingException {
		
		EmployeeAddress1 empAddress=new EmployeeAddress1();
		empAddress.setState("NCR");
		empAddress.setCity("Delhi");
		empAddress.setZip(713304);
		
		EmployeePOJO2 empObj=new EmployeePOJO2();
		empObj.setAge(24);
		empObj.setMarried(false);
		empObj.setName("Tom");
		empObj.setSalary(90000);
		empObj.setEmpAddress(empAddress);
		
		ObjectMapper obj=new ObjectMapper();
	String empJSON=obj.writerWithDefaultPrettyPrinter().writeValueAsString(empObj);
	RestAssured.baseURI="https://reqres.in";
	
	String Response=	given().log().all().headers("content-type","application/json")
		.headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")	
		.body(empJSON)
		
		.when().post("api/users")
		.then().log().all().
		assertThat().statusCode(201)
		.extract().response().asString();
	
	System.out.println(Response);
		
		
		
		

	}

}
