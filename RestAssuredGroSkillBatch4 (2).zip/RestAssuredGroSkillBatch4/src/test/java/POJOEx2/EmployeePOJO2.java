package POJOEx2;

public class EmployeePOJO2 {
	
	private String name;
	private int age;
	private long salary;
	private EmployeeAddress1 empAddress;
	private boolean isMarried;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public long getSalary() {
		return salary;
	}
	public void setSalary(long salary) {
		this.salary = salary;
	}
	public EmployeeAddress1 getEmpAddress() {
		return empAddress;
	}
	public void setEmpAddress(EmployeeAddress1 empAddress) {
		this.empAddress = empAddress;
	}
	public boolean isMarried() {
		return isMarried;
	}
	public void setMarried(boolean isMarried) {
		this.isMarried = isMarried;
	}
	
	
	
	
	
	
	
	

}
