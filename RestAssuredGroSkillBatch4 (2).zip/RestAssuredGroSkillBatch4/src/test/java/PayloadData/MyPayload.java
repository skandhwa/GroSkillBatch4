package PayloadData;

public class MyPayload {
	
	public static String getPayloadData(String name,String jobRole)
	{
		String payloadData="{\r\n"
				+ "    \"name\": \""+name+"\",\r\n"
				+ "    \"job\": \" "+jobRole+"        \"\r\n"
				+ "}";
		
		return payloadData;
	}
	
	public static String addBook(String isbn,String aisle)
	{
		String bookData="{\r\n"
				+ "\r\n"
				+ "\"name\":\"Learn Appium Automation with Java\",\r\n"
				+ "\"isbn\":\""+isbn+"       \",\r\n"
				+ "\"aisle\":\"" +aisle+"\",\r\n"
				+ "\"author\":\"John foe\"\r\n"
				+ "}\r\n"
				+ "";
		
		return bookData;
	}
	
	public static String addBook1(String bookName,String isbn,String aisle)
	{
		String bookData="{\r\n"
				+ "\r\n"
				+ "\"name\":\""+bookName+"\",\r\n"
				+ "\"isbn\":\""+isbn+"       \",\r\n"
				+ "\"aisle\":\"" +aisle+"\",\r\n"
				+ "\"author\":\"John foe\"\r\n"
				+ "}\r\n"
				+ "";
		
		return bookData;
	}
	
	

}
