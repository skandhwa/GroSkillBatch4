package SerializationDeserialization;

import static io.restassured.RestAssured.given;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;



public class CreateEmployee {

	public static void main(String[] args) throws JsonProcessingException {
		
		EmployeePOJO emp=new EmployeePOJO();
		emp.setName("Harry");
		emp.setJob("QA Manager");
		emp.setSalary(80000);
		emp.setMarried(false);
		
		ObjectMapper obj=new ObjectMapper();
		
		RestAssured.baseURI="https://reqres.in";
	String empJSON=obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp);
	String Response=	given().log().all().headers("content-type","application/json")
			.headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")	
			.body(empJSON)
			
			.when().post("api/users")
			.then().log().all().
			assertThat().statusCode(201)
			.extract().response().asString();
		
		System.out.println(Response);
		
		System.out.println("Doing Deserialization");
		
		EmployeePOJO empObj=obj.readValue(Response, EmployeePOJO.class);
		
	    String name=empObj.getJob();
	    
	    System.out.println("name of employee is  "+name);
		
		
	
		
	}

}
