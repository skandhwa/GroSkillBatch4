package RestAssuredGroSkillBatch4.RestAssuredGroSkillBatch4;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
