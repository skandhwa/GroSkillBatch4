package MyPracticeRestAssured;

import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.notNullValue;

import org.testng.Assert;

import PayloadData.MyPayload;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;


public class LibraryAPIEx {

	public static void main(String[] args) {
		
		RestAssured.baseURI="http://216.10.245.166";
		
		String isbn="" + (char)('a' + Math.random()*26) + (char)('a' + Math.random()*26) + (char)('a' + Math.random()*26);
		String aisle=String.valueOf((int)(Math.random() * 900) + 100);
		
		String ExpectedMessage="successfully added";
		
	 Response res=	given().log().all().headers("content-type","application/json")
		
		.body(MyPayload.addBook(isbn,aisle))
		
		.when().post("Library/Addbook.php")
		.then().log().all().body("Msg", notNullValue()).
		
		
		assertThat().statusCode(200)
		.extract().response();
	 
	long time= res.getTime();
	
	if(time>5000)
	{
		System.out.println("Test Case Failed");
	}
	
	else
	{
		JsonPath js=new JsonPath(res.asString());
	String ActualMessage=	js.getString("Msg");
		Assert.assertEquals(ActualMessage, ExpectedMessage);
		
		
		
	}
	
	
	
	
	
		
		

	}

}
