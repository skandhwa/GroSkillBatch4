package MyPracticeRestAssured;

import org.testng.Assert;

import PayloadData.ResponseData;
import io.restassured.path.json.JsonPath;


public class RealTimeAPITestCase {

	public static void main(String[] args) {
		
		JsonPath js=new JsonPath(ResponseData.BookData());
		
		///Print No of courses returned by API

		int courseTotal= js.getInt("courses.size()");
		System.out.println("Total Courses are  "+courseTotal);
		
		//Print Purchase Amount

		int purchaseAmount=js.getInt("dashboard.purchaseAmount");
		System.out.println("Total amount is  "+purchaseAmount);
		
		///Print Title of the first course
        String firstCourseTitle=js.getString("courses[0].title");
        System.out.println("Title of first course is  "+firstCourseTitle);
        
		
		///Print All course titles and their respective Prices
          
       System.out.println("Course Title and their respective prices are\n "); 
       for(int i=0;i<courseTotal;i++)
       {
    	   System.out.print(js.getString("courses["+i+"].title")+" ");
    	   System.out.println(js.getInt("courses["+i+"].price"));
    	  
       }
       
       
       //Print no of copies sold by RPA Course

       for(int i=0;i<courseTotal;i++)
       {
    	  String title= js.getString("courses["+i+"].title");
    	  if(title.equalsIgnoreCase("RPA"))
    	  {
    		int copies=  js.getInt("courses["+i+"].copies");
    		System.out.println("Total copies sold by RPA is  "+copies);
    	  }
    	  
    	  
       }
       
       
       ///Verify if Sum of all Course prices matches with Purchase Amount

        int sum=0;
        for(int i=0;i<courseTotal;i++)
        {
     	  
     	 int price=  js.getInt("courses["+i+"].price");
     	int copies=  js.getInt("courses["+i+"].copies");
     	int amount=price*copies;
     	sum=sum+amount;
     	
     	 
     	  
        }
        
        
        Assert.assertEquals(purchaseAmount, sum);
        System.out.println("All test case passed");
        

	}

}
