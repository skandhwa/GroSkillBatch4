package MyPracticeRestAssured;

import static io.restassured.RestAssured.given;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import PayloadData.MyPayload;
import io.restassured.RestAssured;


public class UsingDPforTestData {
	
	@DataProvider(name="booksData")
	public Object [][] getData()
	{
		return new Object [][]
				
				{
			
			{"Python Skills","gtrf","8654"},
			{"Selenium Overview","jhgr","5490"},
			{"Playwright in Depth","redx","9871"}
			
				};
	}
	
	@Test(dataProvider="booksData")
	public void addBook(String bookName,String isbn,String aisle)
	{
		
		RestAssured.baseURI="http://216.10.245.166";
		String Response=	given().log().all().headers("content-type","application/json")
				.body(MyPayload.addBook1(bookName,isbn,aisle))
				.when().post("Library/Addbook.php")
				
				.then().log().all().assertThat().statusCode(200)
				.extract().response().asString();
		
		System.out.println(Response);
			
	}
	
	

}
