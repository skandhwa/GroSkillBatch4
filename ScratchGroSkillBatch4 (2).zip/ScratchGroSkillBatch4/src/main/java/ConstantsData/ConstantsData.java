package ConstantsData;

public class ConstantsData {
	
	public static final String URL="src/main/java/TestData/TestData23rdDec.xlsx";
    public static final String PropFilePath="src/main/java/Global.properties";
}


