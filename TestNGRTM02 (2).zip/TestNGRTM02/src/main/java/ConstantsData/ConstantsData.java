package ConstantsData;

public class ConstantsData {
	
	public static final String PropertyFilePath="src\\main\\java\\Global.properties";
	public static final String ScreenShotPath="D:\\Scrennshots 12th July\\"+Math.random()+"Test.jpeg";

}
