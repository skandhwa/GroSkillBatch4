package Utilities;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class BaseClass {
	
	public static WebDriver driver;
	public static ExtentReports reports;
	public static ExtentTest test;
	public static ExtentSparkReporter htmlReporter;
	
	@BeforeMethod(alwaysRun=true)
	
	public void launchBrowser() throws IOException
	{
		String browserName=FetchDataFromProperty.readDataFromProperty().getProperty("browser");
		
		if(browserName.equalsIgnoreCase("chrome"))
		{
			driver=new ChromeDriver();
			driver.get(FetchDataFromProperty.readDataFromProperty().getProperty("url"));
			driver.manage().window().maximize();
			
		}
		
		if(browserName.equalsIgnoreCase("firefox"))
		{
			driver=new FirefoxDriver();
			driver.get(FetchDataFromProperty.readDataFromProperty().getProperty("url"));
			driver.manage().window().maximize();
			
		}
		
		if(browserName.equalsIgnoreCase("edge"))
		{
			driver=new EdgeDriver();
			driver.get(FetchDataFromProperty.readDataFromProperty().getProperty("url"));
			driver.manage().window().maximize();
			
		}
		
		
		
		
		}
		
		
		public static void addImplicitWait()
		{
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		}
		
		public static void addExplicitWait(By locator)
		{
			WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(3));
			wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
			
		}
		
		public static void scrollDown()
		{
			JavascriptExecutor js=(JavascriptExecutor)driver;
			js.executeScript("window.scrollBy(0,500)", " ");
		}
		
		public static String getTitle()
		{
			String title=driver.getTitle();
			return title;
		}
		
		
		@AfterMethod(alwaysRun=true)
		public void closeBrowser() throws InterruptedException
		{
			Thread.sleep(3000);
			driver.quit();
		}
		
		
	}
	
	
	
	
	
	
	
	
	


