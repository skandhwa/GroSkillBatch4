package Utilities;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.Reporter;

import ConstantsData.ConstantsData;


public class ListenerImplementation extends BaseClass implements ITestListener  {

	@Override
	public void onTestSuccess(ITestResult result) {
		
		
		ITestListener.super.onTestSuccess(result);
	}

	@Override
	public void onTestFailure(ITestResult result) {
		
		ITestListener.super.onTestFailure(result);
		Reporter.log("My Test case failed");
		
		TakesScreenshot srcshot=(TakesScreenshot)driver;
		File src=srcshot.getScreenshotAs(OutputType.FILE);
		File dest=new File(ConstantsData.ScreenShotPath);
		try {
			FileUtils.copyFile(src, dest);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	
	

}
