import {expect, test} from '@playwright/test'

test('My first validation',async({page})=>
{
 
    await page.goto("https://www.google.com");
    console.log(await page.title());
    await expect(page).toHaveTitle("Google");



})