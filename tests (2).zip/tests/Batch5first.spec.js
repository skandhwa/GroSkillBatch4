import {test} from '@playwright/test'


test.describe.parallel('Parallel Test case',()=>{


test('Myfirst test case', async({page,browser})=>
{

  await page.goto("https://www.google.com")

}
)





test('My second test case', async({page,browser})=>
{

  await page.goto("https://www.instagram.com")

}
)})