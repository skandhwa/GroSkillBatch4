
import { test, expect } from '@playwright/test';

test('Perform drag and drop on jQuery UI Droppable demo with visible wait', async ({ page }) => {
  
  // Navigate to page
  await page.goto('https://jqueryui.com/droppable/');

  // Wait for iframe to load
  await page.waitForSelector('.demo-frame');

  const frameLocator = page.frameLocator('.demo-frame');

  // Locate elements inside iframe
  const draggable = frameLocator.locator('#draggable');
  const droppable = frameLocator.locator('#droppable');


  // Visible wait before drag
  await page.waitForTimeout(2000);

  // Perform drag and drop
  await draggable.dragTo(droppable);

  // Visible wait after drop
  await page.waitForTimeout(2000);

  // Assertion
  await expect(droppable).toHaveText(/Dropped!/i);
});