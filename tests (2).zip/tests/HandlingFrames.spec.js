import { test, expect } from '@playwright/test';

test('Handling Frames',async({page})=>
{
await page.goto("https://demo.automationtesting.in/Frames.html");
const frame = page.frameLocator("#singleframe");

  // Now interact with the input inside the frame

   await page.waitForTimeout(2000);
  await frame.locator("input[type='text']").fill("Saurabh");
 await page.waitForTimeout(2000);




}
);