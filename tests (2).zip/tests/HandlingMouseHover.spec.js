import { test, expect } from '@playwright/test';

test.describe('Mouse Hover Handling - DemoQA Menu', () => {

  test('Handle Multi-Level Hover Menu', async ({ page }) => {

    // Open page
    await page.goto('https://demoqa.com/menu/#');
    await page.waitForTimeout(2500); // Observe page load

    // Hover on Main Item 2
    const mainItem2 = page.locator('text=Main Item 2');
    await mainItem2.hover();
    await page.waitForTimeout(2000); // Observe first hover menu open

    // Hover on SUB SUB LIST
    const subSubList = page.locator('text=SUB SUB LIST');
    await subSubList.hover();
    await page.waitForTimeout(2000); // Observe second level menu

    // Ensure Sub Sub Item 2 is visible before clicking
    const subSubItem2 = page.locator('text=Sub Sub Item 2');
    await expect(subSubItem2).toBeVisible();
    await page.waitForTimeout(1000); // Small pause before click

    // Click on Sub Sub Item 2
    await subSubItem2.click();
    await page.waitForTimeout(3000); // Observe final action

  });

});
