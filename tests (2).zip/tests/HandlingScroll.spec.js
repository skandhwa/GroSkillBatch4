import { test, expect } from '@playwright/test';
test('Scroll to bottom of page', async ({ page }) => {

  await page.goto('https://demoqa.com/');
  await page.waitForTimeout(2000); // Observe page load

  // Scroll to bottom
  await page.evaluate(() => {
    window.scrollTo(0, document.body.scrollHeight);
  });

  await page.waitForTimeout(3000); // Observe scroll

});




test('Scroll down by pixels', async ({ page }) => {

  await page.goto('https://demoqa.com/');
  await page.waitForTimeout(2000);

  // Scroll down 500 pixels
  await page.evaluate(() => {
    window.scrollBy(0, 500);
  });

  await page.waitForTimeout(2000);

  // Scroll another 500 pixels
  await page.evaluate(() => {
    window.scrollBy(0, 500);
  });
   await page.waitForTimeout(3000);

});



test('Scroll until element visible', async ({ page }) => {

  await page.goto('https://demoqa.com/');
  await page.waitForTimeout(2000);

  const element = page.locator('text=Book Store Application');

  await element.scrollIntoViewIfNeeded();
  await page.waitForTimeout(3000);

  await expect(element).toBeVisible();

});





test('Scroll using mouse wheel', async ({ page }) => {

  await page.goto('https://demoqa.com/');
  await page.waitForTimeout(2000);

  await page.mouse.wheel(0, 600);
  await page.waitForTimeout(2000);

  await page.mouse.wheel(0, 600);
  await page.waitForTimeout(3000);

});


