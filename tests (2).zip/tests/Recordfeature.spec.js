import { test, expect } from '@playwright/test';

test('test', async ({ page }) => {
  await page.goto('https://www.google.com/?zx=1770825428585&no_sw_cr=1');
  await expect(page.getByRole('button', { name: 'Google Search' })).toBeVisible();
  await expect(page.locator('#SIvCob')).toContainText('Google offered in: हिन्दी বাংলা తెలుగు मराठी தமிழ் ગુજરાતી ಕನ್ನಡ മലയാളം ਪੰਜਾਬੀ');
  await page.getByRole('combobox', { name: 'Search' }).click();
  await page.getByRole('combobox', { name: 'Search' }).fill('Latest Movies bollywood');
  await page.goto('https://www.google.com/sorry/index?continue=https://www.google.com/search%3Fq%3DLatest%2BMovies%2Bbollywood%26sca_esv%3Db1aa0ebf47929ca9%26source%3Dhp%26ei%3D06aMaYzuGKyvseMP2PWOsAs%26iflsig%3DAFdpzrgAAAAAaYy044RvzS7qP-Am7Jo_6DY78_TaruV_%26ved%3D0ahUKEwjMo73k5tGSAxWsV2wGHdi6A7YQ4dUDCCg%26uact%3D5%26oq%3DLatest%2BMovies%2Bbollywood%26gs_lp%3DEgdnd3Mtd2l6IhdMYXRlc3QgTW92aWVzIGJvbGx5d29vZDIFEAAYgAQyBRAAGIAEMgUQABiABDIFEAAYgAQyBRAAGIAEMgUQABiABDIFEAAYgAQyBRAAGIAEMgUQABiABDIFEAAYgARIiW9Q-y9Y7ltwAHgAkAEAmAGPAqABqx-qAQYwLjE5LjW4AQPIAQD4AQGYAhigAukfqAIKwgIKEAAYAxjqAhiPAcICERAuGIAEGLEDGNEDGIMBGMcBwgIOEAAYgAQYsQMYgwEYigXCAgsQABiABBixAxiDAcICCBAAGIAEGLEDwgIFEC4YgATCAg4QLhiABBixAxjRAxjHAcICCBAuGIAEGLEDmAOcAfEFbh1VVE8OKXSSBwYwLjE5LjWgB-2aAbIHBjAuMTkuNbgH6R_CBwYwLjIzLjHIByqACAA%26sclient%3Dgws-wiz%26sei%3DCqeMacvkPKiPseMPhurVmQY&q=EhAkBQIBwAuA0lCqCfLxWDO1GIvOsswGIjDq3hc7hWmvJAN7SDZPPKwbKfu3uckIK0pK72U1xw8X-1L4wEhT43xYDkR5bbHOnnAyAVJaAUM');
});


