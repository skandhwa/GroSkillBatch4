import { test, expect } from '@playwright/test';

test.describe('Handle All Types of Alerts With Waits', () => {

  test('Handle Simple Alert', async ({ page }) => {

    await page.goto('https://demo.automationtesting.in/Alerts.html');
    await page.waitForTimeout(2000);   // Wait 2 seconds

    // Register dialog handler
    page.once('dialog', async dialog => {
      console.log('Simple Alert Message:', dialog.message());
      await page.waitForTimeout(2000);  // See alert for 2 seconds
      await dialog.accept();
    });

    await page.click('button[onclick="alertbox()"]');
    await page.waitForTimeout(2000);   // Wait after closing alert
  });



  test('Handle Confirmation Alert (OK & Cancel)', async ({ page }) => {

    await page.goto('https://demo.automationtesting.in/Alerts.html');
    await page.waitForTimeout(2000);

    await page.click('a[href="#CancelTab"]');
    await page.waitForTimeout(2000);

    // ---- Handle OK ----
    page.once('dialog', async dialog => {
      console.log('Confirmation Alert Message:', dialog.message());
      await page.waitForTimeout(2000);
      await dialog.accept();
    });

    await page.click('button[onclick="confirmbox()"]');
    await page.waitForTimeout(2000);

    await expect(page.locator('#demo')).toHaveText('You pressed Ok');
    await page.waitForTimeout(2000);

    // ---- Handle Cancel ----
    page.once('dialog', async dialog => {
      await page.waitForTimeout(2000);
      await dialog.dismiss();
    });

    await page.click('button[onclick="confirmbox()"]');
    await page.waitForTimeout(2000);

    await expect(page.locator('#demo')).toHaveText('You Pressed Cancel');
    await page.waitForTimeout(2000);
  });



  test('Handle Prompt Alert', async ({ page }) => {

    await page.goto('https://demo.automationtesting.in/Alerts.html');
    await page.waitForTimeout(2000);

    await page.click('a[href="#Textbox"]');
    await page.waitForTimeout(2000);

    page.once('dialog', async dialog => {
      console.log('Prompt Alert Message:', dialog.message());
      await page.waitForTimeout(2000);
      await dialog.accept('Playwright Demo');
    });

    await page.click('button[onclick="promptbox()"]');
    await page.waitForTimeout(2000);

    await expect(page.locator('#demo1'))
      .toHaveText('Hello Playwright Demo How are you today');

    await page.waitForTimeout(3000);
  });

});