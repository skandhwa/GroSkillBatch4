import { test, expect } from '@playwright/test';

test.describe('Handle Frames and Nested Frames With Waits', () => {

  test('Handle Single Frame', async ({ page }) => {

    await page.waitForTimeout(2000);
    await page.goto('https://demo.automationtesting.in/Frames.html');

    await page.waitForTimeout(2000);

    // Locate single frame
    const singleFrame = page.frame({ name: 'SingleFrame' });

    await page.waitForTimeout(2000);

    // Type inside textbox in single frame
    await singleFrame.locator('input[type="text"]')
                     .fill('Inside Single Frame');

    await page.waitForTimeout(3000);
  });



  test('Handle Nested Frame', async ({ page }) => {

    await page.waitForTimeout(2000);
    await page.goto('https://demo.automationtesting.in/Frames.html');

    await page.waitForTimeout(2000);

    // Click Nested Frames tab
    await page.click('a[href="#Multiple"]');

    await page.waitForTimeout(3000);

    // Locate parent frame
    const parentFrame = page.frameLocator('iframe[src="MultipleFrames.html"]');

    await page.waitForTimeout(2000);

    // Locate child frame inside parent
    const childFrame = parentFrame.frameLocator('iframe');

    await page.waitForTimeout(2000);

    // Type inside textbox in nested frame
    await childFrame.locator('input[type="text"]')
                    .fill('Inside Nested Frame');

    await page.waitForTimeout(4000);
  });

});