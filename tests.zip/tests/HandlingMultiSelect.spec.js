
import { test, expect } from '@playwright/test';

test('Handling Multi Select',async({page})=>
{

await page.goto('https://www.techlistic.com/p/selenium-practice-form.html#google_vignette');
const dropDownValue=await page.locator("[id='selenium_commands']");
await dropDownValue.selectOption({index:1});
await dropDownValue.selectOption({index:2});
await dropDownValue.selectOption({index:3});


  

}
)