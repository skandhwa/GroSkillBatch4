import { test, expect } from '@playwright/test';

test('Handling Windows',async({browser})=>
{

  const context=await browser.newContext();
  const page=await context.newPage();
await page.goto("https://demo.automationtesting.in/Windows.html");
const docLink=await page.locator("(//button[@class='btn btn-info'])[1]");
const [newPage]=await Promise.all([context.waitForEvent('page'),docLink.click()]);
await newPage.waitForLoadState();
console.log(await newPage.title());




}

)