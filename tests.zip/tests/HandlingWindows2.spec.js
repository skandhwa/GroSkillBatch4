import { test, expect } from '@playwright/test';

test.describe('Handle Multiple Windows with Visible Waits', () => {

  test('Handling Windows',async({browser})=>
{

  const context=await browser.newContext();
  const page=await context.newPage();
await page.goto("https://demo.automationtesting.in/Windows.html");
const docLink=await page.locator("(//button[@class='btn btn-info'])[1]");
const [newPage]=await Promise.all([context.waitForEvent('page'),docLink.click()]);
await newPage.waitForLoadState();
console.log(await newPage.title());




}

)



  test('Handle Separate Window Tab', async ({ page, context }) => {

    await page.goto('https://demo.automationtesting.in/Windows.html');
    await page.waitForTimeout(2000);

    // Click on "Open New Seperate Windows" tab
    await page.click('a[href="#Seperate"]');
    await page.waitForTimeout(2000);

    const [newPage] = await Promise.all([
      context.waitForEvent('page'),
      page.click('button[onclick="newwindow()"]')
    ]);

    await newPage.waitForLoadState();
    await page.waitForTimeout(3000);

    console.log("Separate Window Title:", await newPage.title());

    await newPage.waitForTimeout(2000);
    await newPage.close();

    await page.waitForTimeout(2000);
  });
test('Handle Multiple Tabs', async ({ page, context }) => {

    await page.goto('https://demo.automationtesting.in/Windows.html');
    await page.waitForTimeout(2000);

    // Click on Multiple Windows tab
    await page.click('a[href="#Multiple"]');
    await page.waitForTimeout(2000);

    const [multiPage] = await Promise.all([
      context.waitForEvent('page'),
      page.click('button[onclick="multiwindow()"]')
    ]);

    await multiPage.waitForLoadState();
    await page.waitForTimeout(3000);

    console.log("Multiple Window Title:", await multiPage.title());

    await multiPage.waitForTimeout(2000);
    await multiPage.close();

    await page.waitForTimeout(2000);
  });

});