import { test, expect } from '@playwright/test';

test('first playwright test',async({page})=>
{
await page.goto("https://www.google.com");
}
)


test('first playwright test part B',async({page})=>
{
await page.goto("https://www.instagram.com");
}
)


test('first playwright test part C',async({page})=>
{
await page.goto("https://www.amazon.com");
}
)