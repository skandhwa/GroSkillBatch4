import { test, expect } from '@playwright/test';

test('My Practice Form',async({page})=>
{

    
    await page.goto("https://demo.automationtesting.in/Register.html");
    console.log(await page.title());
   
    await expect(page).toHaveTitle("Register");
    console.log("Assertions passed");
    await page.waitForTimeout(2000);
    
    const pageTitleVal=await page.locator("//h2").textContent();
    expect (pageTitleVal).toContain("Register")
    await page.waitForTimeout(2000);

    
    const fName= await page.locator("[placeholder='First Name']");
 
    
    fName.fill("Saurabh");
   
    
   const gender=await page.locator("[value='Male']");
   gender.click();
   await page.waitForTimeout(2000);

    const dropDownValue=await page.locator("[id='Skills']");
    await page.waitForTimeout(2000);

    const texts= await page.locator("[id='Skills']").allTextContents();
    console.log(texts);
   await page.waitForTimeout(2000);

    //await dropDownValue.selectOption({index:2});///first 
    //await dropDownValue.selectOption('Android');
    await dropDownValue.selectOption({label:'Analytics'});
  await page.waitForTimeout(2000);
    await expect(dropDownValue).toHaveValue('Analytics');






    


   







    


  







}
)